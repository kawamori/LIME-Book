if (typeof(BML) == 'undefined') throw('BML.js not loaded yet');
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// 
/** ����browser���֥������� ** @namespace */
browser = (function() {
  ///////////////////////////////////////////////////////////////////////////////////////////
  // dummy function ->
  function getDRMID(str)  { return('1234567890abcdef'); }
  function getIRDID(type) { return('1234567890abcdef'); }
  function getDocManagementStat()     { return(true); } // managed/unmanaged
  function readPersistentArray(fn, s) { return([20, false]); } //[ǯ��, ���¾���] 
  function checkIPTVServiceRegistrationInfo(id) { return([12345678, 0, 'license']); } // key,expire_date,license_uri
  function epgTune(serviceRef) {
//    if (typeof(epgTune.caller) == 'function') { // called in a function code
//    } else { // called in the global code : don't call onunload event
//      BML.Builder.eventHandler['onunload'] = '';
//    }
    throw('[!]epgTune called('+serviceRef+'): skip all javascript process');
  } // 
  function getIPTVLicense(drmSystem, ipSrvcPrvdrId, licenseArray) { return(1); }
  // <- dummy function

  // ARIB
//function epgTune() {} -> dummy
//function readPersistentArray() {} -> dummy
  function transmitTextDataOverIP(url, text, charset) {
    charset = charset || 'EUC-JP';
    var ajax = new BML.Ajax(url,
                            ((text === null) || BML.Util.isUndefined(text)) ?
                            {
                              overrideMimeType : 'text/plane; charset=' + charset,
                              asynchronous     : false,
                              method           : 'GET'
                            } : 
                            {
                              overrideMimeType : 'text/plane; charset=' + charset,
                              asynchronous     : false,
                              method           : 'POST',
                              parameters       : { Denbun : text }
                            });
    var httpStatusCode = ajax.response.statusCode;
    if ((httpStatusCode < 200) || (httpStatusCode >= 300)) {
      if      (httpStatusCode ==  400) return([-1,  httpStatusCode, '']);
      else if (httpStatusCode ==  408) return([-3,  httpStatusCode, '']);
      else if (httpStatusCode !==   0) return([NaN, httpStatusCode, '']);
    }

    return([1, 200, ajax.response.responseText]);
  }
//function setCacheResourceOverIP() {}
//reloadActiveDocument() {}
//getBrowserVersion() {}
  function getActiveDocument() {
    var uri = BML.Util.parseURI(BML.url);
    return('/' + uri.path + uri.file +
           ((uri.query    !== '') ? '?'+ uri.query    : '') +
           ((uri.fragment !== '') ? '#'+ uri.fragment : ''));
  }
  function lockScreen()   {}
  function unlockScreen() {}
//function getBrowserSupport() {}
//  function launchDocument(url, style) {
//    BML.Debug('[[[[[[[[[[[[[[[[[[[[[launchDocument]]]]]]]]]]]]]]]]]]]]]');
//    url = (url || '').replace(/\.bml((\?\.+)?)/, '.html$1');
//    if (url === '') return(NaN);
//    location.href=url;
//    return(1);
//  }
//function quitDocument() {}
//function getResidentAppVersion() {}
//function startResidentApp() {}
//function playRomSound(sID) {}
//function sleep() {}
  function setInterval(func, ms, repeat) {
    ms = Math.max(100, Math.floor((ms + 99) / 100) * 100); // �����ͤ�100msñ��
    if (repeat === 0) repeat = -1;
    var timer = window.setInterval(function() {
      eval(func);
      if ((repeat > 0) && (--repeat === 0)) window.clearInterval(timer);
    }, ms);
    return(timer);
  }
  function clearTimer(id) { window.clearInterval(id); }
//function pauseTimer() {}
//function resumeTimer() {}
  function random(n) { return(1 + Math.floor(Math.random() * n)); }
  function addDate(base, time, unit) { // unit [0:ms, 1:sec, 2:min, 3:hour, 4:day, 5:week]
    var t = base.getTime();
    if      (unit === 0) t += time;
    else if (unit ==  1) t += time * 1000;
    else if (unit ==  2) t += time * 1000 * 60;
    else if (unit ==  3) t += time * 1000 * 60 * 60;
    else if (unit ==  4) t += time * 1000 * 60 * 60 * 24;
    else if (unit ==  5) t += time * 1000 * 60 * 60 * 24 * 7;
    var ret = new Date; ret.setTime(t);
    return(ret);
  }
  function subDate(target, base, unit) { // unit [0:ms, 1:sec, 2:min, 3:hour, 4:day, 5:week]
    var diff = target.getTime() - base.getTime();
    if      (unit == 1) diff = Math.floor(diff /  1000);
    else if (unit == 2) diff = Math.floor(diff / (1000 * 60));
    else if (unit == 3) diff = Math.floor(diff / (1000 * 60 * 60));
    else if (unit == 4) diff = Math.floor(diff / (1000 * 60 * 60 * 24));
    else if (unit == 5) diff = Math.floor(diff / (1000 * 60 * 60 * 24 * 7));
    return(diff);
  }
  function formatNumber(value) {
    value = String(value);
    var len = value.length;
    if (len < 3) return(value);
    
    var odd = len % 3, buf = [];
    if (odd > 0) buf.push(value.substring(0, odd));
    for(var i = odd; i < len; i+=3) {
      buf.push(value.substring(i, i+3));
    }
    return(buf.join(','));
  }
//function getPrinterStatus() {}
//function printFile() {}
//function printTemplate() {}
//function printURI() {}
//function printStaticScreen() {}
//function saveImageToMemoryCard() {}
//function saveHttpServerImageToMemoryCard() {}
//function saveStaticScreenToMemoryCard() {}
//function launchDynamicDocument() {}
//function getMetadataElement() {}
//function getSynopsis() {}
//function searchMetadata() {}
//function searchMetadataOnServer() {}

  // IPTVFJ(CDN Scope)
//function getIPTVLicense() {} -> dummy
//function getIPTVLicenseInfo() {}
//function getDRMID() {} -> dummy
//function launchIPTVContent() {}
//function launchUnmanagedDocument() {}
//function getDocManagementState() {} -> dummy
//function marqueeText() {}
//function setIPTVServiceRegistrationInfo() {}
//function checkIPTVServiceRegistrationInfo() {} -> dummy
//function setTBServiceRegistrationInfo() {}
//function checkTBServiceRegistrationInfo() {}
//function setContentPackageInfo() {}
//function setSelectedLicenseInfo() {}
//function updatePackageLicenseInfo() {}
//function checkParentalCtrlPassword() {}

  // IPTVFJ(IPRetransmission);
//  function getIRDID() {} -> dummy
  
  return({
    epgTune                          : epgTune,
    readPersistentArray              : readPersistentArray,
    transmitTextDataOverIP           : transmitTextDataOverIP,
//  setCacheResourceOverIP           : setCacheResourceOverIP,
//  reloadActiveDocument             : reloadActiveDocument,
//  getBrowserVersion                : getBrowserVersion,
    getActiveDocument                : getActiveDocument,
    lockScreen                       : lockScreen,
    unlockScreen                     : unlockScreen,
//  getBrowserSupport                : getBrowserSupport,
//  launchDocument                   : launchDocument,
//  quitDocument                     : quitDocument,
//  getResidentAppVersion            : getResidentAppVersion,
//  startResidentApp                 : startResidentApp,
//  playRomSound                     : playRomSound,
//  sleep                            : sleep,
    setInterval                      : setInterval,
    clearTimer                       : clearTimer,
//  pauseTimer                       : pauseTimer,
//  resumeTimer                      : resumeTimer,
    random                           : random,
    addDate                          : addDate,
    subDate                          : subDate,
    formatNumber                     : formatNumber,
//  getPrinterStatus                 : getPrinterStatus,
//  printFile                        : printFile,
//  printTemplate                    : printTemplate,
//  printURI                         : printURI,
//  printStaticScreen                : printStaticScreen,
//  saveImageToMemoryCard            : saveImageToMemoryCard,
//  saveHttpServerImageToMemoryCard  : saveHttpServerImageToMemoryCard,
//  saveStaticScreenToMemoryCard     : saveStaticScreenToMemoryCard,
//  launchDynamicDocument            : launchDynamicDocument,
//  getMetadataElement               : getMetadataElement,
//  getSynopsis                      : getSynopsis,
//  searchMetadata                   : searchMetadata,
//  searchMetadataOnServer           : searchMetadataOnServer,

    getIPTVLicense                   : getIPTVLicense,
//  getIPTVLicenseInfo               : getIPTVLicenseInfo,
    getDRMID                         : getDRMID,
//  launchIPTVContent                : launchIPTVContent,
//  launchUnmanagedDocument          : launchUnmanagedDocument,
    getDocManagementStat             : getDocManagementStat,
//  marqueeText                      : marqueeText,
//  setIPTVServiceRegistrationInfo   : setIPTVServiceRegistrationInfo,
    checkIPTVServiceRegistrationInfo : checkIPTVServiceRegistrationInfo,
//  setTBServiceRegistrationInfo     : setTBServiceRegistrationInfo,
//  checkTBServiceRegistrationInfo   : checkTBServiceRegistrationInfo,
//  setContentPackageInfo            : setContentPackageInfo,
//  setSelectedLicenseInfo           : setSelectedLicenseInfo,
//  updatePackageLicenseInfo         : updatePackageLicenseInfo,
//  checkParentalCtrlPassword        : checkParentalCtrlPassword,

    getIRDID                         : getIRDID
  });
})();
