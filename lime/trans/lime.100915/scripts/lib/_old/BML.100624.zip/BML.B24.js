if (typeof(BML) == 'undefined') throw('BML.js not loaded yet');

var browser = (typeof(browser) != 'undefined') ? browser : {};
BML.Util.extend(browser, (function() {
  function UregObject() { this.data = new Array(64); }

  // browser.Ureg�̋[���I�u�W�F�N�g
  // �d�l�͉��L�̂Ƃ���Ȃ̂ŁCgetteer/setter��p���ċ[���I�Ȕz����쐬���C
  // �����񒷔���Ȃǂ��n���h������D
  // @Todo�FUserData�Ƃ��ău���E�U���ɕۑ�����
  //
  // B24 ���� 7.6.15 Ureg �^���I�u�W�F�N�g����
  // �uUreg �́A0�`63 �܂ł�64 �̒l��ێ����A�v�u������̃T�C�Y�͍ő�256 �o�C�g
  // �ł���B�v�u256 �o�C�g�܂ł��i�[����B256 �o�C�g�ڂ�2 �o�C�g������1 �o�C�g��
  // �������ꍇ�́A���Y�����͊i�[����Ȃ��B�v
  for(var i = 0; i < 64; i++) {
    UregObject.prototype.__defineGetter__(i, function() {
      return(this.data[i]);
    });
    UregObject.prototype.__defineSetter__(i, function(val) {
      if (val.length <= 128) {
        // �����񒷔��肪�s�v�ȏꍇ
        this.data[i] = val;
      } else {
        // �����񒷔���
        var pos = 0;
        for(var cl, len = 0, max = val.length; pos < max; pos++) {
          cl = val.charCodeAt(pos);
          if ((len + cl) > 256) break;
          len += cl;
        }
        this.data[i] = val.substring(0, pos - 1);
      }
    });
  }
  
  return({
    Ureg : new UregObject()
  });
})());


var BinaryTable = (function() {
  // �o�C�g�񂩂�C�ӂ̃o�C�g/�r�b�g����擾���邽�߂̓����N���X
  function ByteHandler(bytes) {
    this.bytes = bytes || [];
    this.pos   = 0; // bit position
    this.idx   = 0; // byte array index
  }
  ByteHandler.prototype.push = function(bite) {
    this.bytes.push(bite);
  };
  ByteHandler.prototype.hasNextBit = function() {
    var max = this.bytes.length - 1;
    return( (this.idx <  max) ||
           ((this.idx == max) && (this.pos < 8)));
  };
  ByteHandler.prototype.hasNextByte = function() {
    var max = this.bytes.length - 1;
    return( (this.idx <  max) ||
           ((this.idx == max) && (this.pos === 0)));
  };
  // �o�C�g�񂩂�̃o�C�g�P�ʂł̃f�[�^�擾
  // @param   {Number} len �o�C�g��
  // @returns {Array}      �e�o�C�g�P�ʂ̐����l�\�����i�[����z��
  ByteHandler.prototype.getBytes = function(len) {
    len = isNaN(len) ? 1 : len;

    var ret = [], i;
    var bytes = this.bytes, idx = this.idx, pos = this.pos;
    if (pos === 0) {
      for(i = 0; i < len; i++) {
        ret[i] = bytes[idx++];
      }
    } else {
      for(i = 0; i < len; i++) {
        var buf = (bytes[idx++] << 8) | bytes[idx];
        ret[i] = (buf >> (8 - pos)) & 0xff;
      }
    }
    this.idx = idx;
    
    return(ret);
  };
  // �o�C�g�񂩂�̃o�C�g�f�[�^�擾
  // @returns {Number} �o�C�g�l�̐����l�\��
  ByteHandler.prototype.getByte = function() {
    return(this.getBytes(1)[0]);
  };
  // �o�C�g�񂩂�̐����l�擾
  // @param   {Number} len �o�C�g��
  // @returns {Number}     �o�C�g�l�̐����l�\��
  ByteHandler.prototype.getBytesAsInteger = function(len) {
    var bytes = this.getBytesAsUnsignedInteger(len);

    var msb = 0x80;
    for(var i = 1; i < len; i++) {
      msb  = (msb  << 8) | 0x00;
    }
    var mask = ~msb;
    // �ŏ�ʃr�b�g�`�F�b�N(�����`�F�b�N)
    if ((ret & msb) > 0) ret = (ret & mask) - msb;
    
    return(ret);
  };
  ByteHandler.prototype.getBytesAsUnsignedInteger = function(len) {
    var bytes = this.getBytes(len);
    var ret = 0;
    for(var i = 0; i < len; i++) {
      ret = (ret << 8) | bytes[i];
    }
    return(ret);
  };
  // �o�C�g�񂩂�̃r�b�g��̎擾
  // @param   {Number} len    �r�b�g��
  // @param   {Number} [mask] �r�b�g���̃}�X�N�\��(�I�v�V����)
  // @returns {Number}        �r�b�g��̐����l�\��
  ByteHandler.prototype.getBits = function(len, mask) {
    var i, l;
    if (!mask) {
      for(mask = 0x01, i = 1; i < len; i++) { mask = (mask << 1) | 0x01; }
    }
  
    var ret, shift;
    var bytes = this.bytes, idx = this.idx, pos = this.pos;
    if (len < 8) { // 1byte�����Ȃ�
      shift = 8 - pos - len;
      if (shift >= 0) {
        ret = bytes[idx];
        ret = (ret >>> shift) & mask;
        this.pos += len;
      } else {
        ret = (bytes[idx++] << 8) & bytes[idx];
        ret = (ret >>> (8 + shift)) & mask;
        this.pos = -shift;
      }
      this.idx = idx;
    } else { // 1byte�ȏ�Ȃ�
      ret = bytes[idx];
      for(i = 1, l = Math.ceil((pos + len) / 8); i < l; i++) {
        ret = (ret << 8) & bytes[++idx];
      }
      this.pos = (pos + len) % 8;
      shift    = (8 - this.pos) % 8;
      ret      = (ret >>> shift) & mask;
      this.idx = idx;
    }
    return(ret);
  };
  ByteHandler.prototype.getBitsAsUnsignedInteger = function(len, mask) {
    return(this.getBits(len, mask));
  };
  ByteHandler.prototype.getBitsAsInteger = function(len) {
    var msb = 0x01;
    for(i = 1; i < len; i++) {
      msb  = (msb  << 1) | 0x00;
    }
    var mask = ~msb;
    
    var bits = this.getBits(len, msb | mask);
    // �ŏ�ʃr�b�g�`�F�b�N(�����`�F�b�N)
    if ((bits & msb) > 0) bits = (bits & mask) - msb;
    
    return(bits);
  };
  
  function parseStructure(structure) {
    var columns    = structure.split(',');
    var lengthByte = columns.shift();

    structure = [];
    var length, unit, mask;
    for(i = 0, l = columns.length; i < l; i++) {
      var match = /^(\w):(\d+)(\w)$/.exec(columns[i]);
      if (!match) throw('[BinaryTableInvalidStructure] : '+columns[i]);

      
      length = parseInt(match[2], 10);
      unit   = match[3];
      mask   = 0x01;
      
      if (unit == 'b') {
        for(i = 1; i < length; i++) {
          mask = ((mask << 1) | 0x01);
        }
      }
      structure.push({
        type   : match[1],
        length : length,
        unit   : unit,
        mask   : mask
      });
    }
    structure.lengthByte = lengthByte;
    return(structure);
  }
  function zipCodeToInteger(digit, a, b, c, d, e) {
    return(digit * 100000 + a * 10000 + b * 1000 + c * 100 * d * 10 * e);
  }
  function includeZipCode(zipCode, list) {
    for(var i = 0, l = list.length; i < l; i++) {
      var condition = list[i];
      if ((condition.from <= zipCode) && (zipCode <= condition.to)) return(true);
    }
    return(false);
  }

  // BinaryTable�̎���
  function BinaryTableClass(table_ref, structure) {
    // ARIB STD-B24 ���ҁu7.5.2.2 BinaryTable �I�u�W�F�N�g�̃R���X�g���N�^�v
    // �f�[�^�̎擾
    var uri = BML.Util.combinePath(table_ref, BML.uri);
    var ajax = new BML.Ajax(uri, {
    overrideMimeType : 'text/plain; charset=x-user-defined',
    asynchronous     : false,
    method           : 'GET'
    });
    // @Todo�F�X�e�[�^�X�R�[�h�̈������]���U�C
    if (ajax.response.statusCode != 200) throw('[FileNotFound] :'+uri);

    // �o�C�g��Ƃ��ăo�b�t�@
    var byteHandler = new ByteHandler(), i, l;
    var stream = ajax.response.responseText;
    for(i = 0, l = stream.length; i < l; i++) {
      byteHandler.push(stream._charCodeAt_(i) & 0x00ff);
    }
    
    // structure�̉��
    structure = parseStructure(structure);
    
    // �e�[�u���̍쐬
    var table = [], entry;
    while(1) {
      if (!byteHandler.hasNextBit()) break;
      // @Todo�FlengthByte���܂��߂ɐ����邩?
      
      entry = [];
      for(i = 0, l = structure.length; i < l; i++) {
        var field = structure[i];
        
        switch(field.type) {
          case('B') : {
            // Boolean
            entry.push(new Boolean((byteHandler.getBits(1) > 0)));
          } break;
          case('U') : {
            // Unsigned Integer
            entry.push(new Number((field.unit == 'b') ?
                                  byteHandler.getBitsAsUnsignedInteger (field.length, field.mask) :
                                  byteHandler.getBytesAsUnsignedInteger(field.length)));
            } break;
          case('I') : {
            entry.push(new Number(byteHandler.getBytesAsInteger(field.length)));
          } break;
          case('S') : {
            if (field.unit == 'B') { // �Œ蒷�ŕ�������擾����
              entry.push(String.charCodeFrom.apply(null,
                                                      byteHandler.getBytes(field.length)));
            } else { // 'V'�F�ϒ���������̏��ԂŎ擾����
              length = byteHandler.getBytesAsUnsignedInteger(field.length);
              entry.push(String.charCodeFrom.apply(null,
                                                   byteHandler.getBytes(length)));
            }
          } break;
          case('P') : {
            (field.unit == 'b') ?
              byteHandler.getBitsAsUnsignedInteger (field.length, field.mask) :
              byteHandler.getBytesAsUnsignedInteger(field.length);
          } break;
          case('Z') : {
            length    = byteHandler.getBytesAsUnsignedInteger(field.length);
            var whole = { include : {}, exclude : {} };

            var includeListNum = byteHandler.getBytesAsUnsignedInteger(1) - 1;
            var excludeListNum = byteHandler.getBytesAsUnsignedInteger(1) / 4;
            includeListNum = includeListNum / 4 - excludeListNum;

            BML.Util.each.call([[whole.exclude, excludeListNum],
                                [whole.include, includeListNum]], function(param) {
              var list = param[0], rangeFrom, msb, from, to, digits, flag, a, b, c, d, e;
              for(var i = 0, l = param[1];  i < l; i++) {
                msb = byteHandler.getBits(1);

                if (!msb) {
                  from = byteHandler.getBitsAsUnsignedInteger(7) * 10;
                  msb  = byteHandler.getBits(1);
                  to   = byteHandler.getBitsAsUnsignedInteger(7) * 10;
                  list.push({
                    from  : (from + 0) * 10000 +     0,
                    to    : (to   + 9) * 10000 +  9999
                  });
                  if (msb) {
                    from = byteHandler.getBitsAsUnsignedInteger(7) * 10;
                    msb  = byteHandler.getBits(1);
                    to   = byteHandler.getBitsAsUnsignedInteger(7) * 10;
                    list.push({
                      from  : (from + 0) * 10000 +     0,
                      to    : (to   + 9) * 10000 +  9999
                    });
                  } else {
                    byteHandler.getBytesAsInteger(2);
                  }

                } else {
                  digits = byteHandler.getBitsAsUnsignedInteger(7);
                  flag   = byteHandler.getBitsAsUnsignedInteger(4);
                  a      = byteHandler.getBitsAsUnsignedInteger(4);
                  b      = byteHandler.getBitsAsUnsignedInteger(4);
                  c      = byteHandler.getBitsAsUnsignedInteger(4);
                  d      = byteHandler.getBitsAsUnsignedInteger(4);
                  e      = byteHandler.getBitsAsUnsignedInteger(4);
                  
                  switch(flag) {
                    case(0x08) : {
                      BML.Util.each.call([a, b, c, d, e], function(num) {
                        if (num == 0x0f) return;
                        list.push({
                          from  : zipCodeToInteger(digits, num, 0, 0, 0, 0),
                          to    : zipCodeToInteger(digits, num, 9, 9, 9, 9)
                        });
                      });
                      rangeFrom = null;
                    } break;
                    case(0x09) : {
                      BML.Util.each.call([[b, c], [d, e]], function(num) {
                        if ((num[0] == 0x0f) || (num[1] == 0x0f)) return;
                        list.push({
                          from  : zipCodeToInteger(digits, num[0], 0, 0, 0, 0),
                          to    : zipCodeToInteger(digits, num[1], 9, 9, 9, 9)
                        });
                      });
                      rangeFrom = null;
                    } break;
                    case(0x0a) : {
                      BML.Util.each.call([[b, c], [d, e]], function(num) {
                        if ((num[0] == 0x0f) || (num[1] == 0x0f)) return;
                        list.push({
                          from  : zipCodeToInteger(digits, a, num[0], num[1], 0, 0),
                          to    : zipCodeToInteger(digits, a, num[0], num[1], 9, 9)
                        });
                      });
                      rangeFrom = null;
                    } break;
                    case(0x0b) : {
                      rangeFrom = zipCodeToInteger(digits, a, b, c, 0, 0);
                    } break;
                    case(0x0c) : {
                      if (!rangeFrom) throw('[InvalidFieldFormat] : 5 digit range from not defined');
                      list.push({
                        from  : rangeFrom,
                        to    : zipCodeToInteger(digits, a, b, c, 9, 9)
                      });
                      rangeFrom = null;
                    } break;
                    case(0x0d) : {
                      rangeFrom = zipCodeToInteger(digits, a, b, c, d, e);
                    } break;
                    case(0x0e) : {
                      if (!rangeFrom) throw('[InvalidFieldFormat] : 7 digit range from not defined');
                      list.push({
                        from  : rangeFrom,
                        to    : zipCodeToInteger(digits, a, b, c, d, e)
                      });
                      rangeFrom = null;
                    } break;
                    case(0x0f) : {
                      list.push({
                        from  : zipCodeToInteger(digits, a, b, c, d, e),
                        to    : zipCodeToInteger(digits, a, b, c, d, e)
                      });
                      rangeFrom = null;
                    } break;
                    default : { break; }
                  }
                }
              }
            });
            entry.push(whole);
          } break;
        default : { break; }
        }
      }
      table.push(entry);
    }
    var buf = []; // remove padding field
    for(i = 0, l = structure.length; i < l; i++) {
      entry = structure[i];
      if (entry.type != 'P') buf.push(entry);
    }
    this.structure = buf;
    this.table     = table;
    this.nrow      = table.length;
    this.ncolumn   = buf.length;
    
    return(this);
  }

  BinaryTableClass.prototype.close = function() {
    this.structure = null;
    this.table     = null;
    return(1);
  };

  BinaryTableClass.prototype.toString = function(row, column) {
    if (((row    < 0) || (this.nrow    <= row   )) ||
        ((column < 0) || (this.ncolumn <= column))) return(null);

    var value = this.table[row][column];
    switch(this.structure[column].type) {
      case('B') : return(value.toString());
      case('U') : return(value.toString());
      case('I') : return(value.toString());
//    case('S') : return(value);
      case('Z') : return(null);
      default   : return(value);
    }
    return(value);
  };

  BinaryTableClass.prototype.toNumber = function(row, column) {
    if (((row    < 0) || (this.nrow    <= row   )) ||
        ((column < 0) || (this.ncolumn <= column))) return(NaN);

    var value = this.table[row][column];
    switch(this.structure[column].type) {
      case('B') : return(value.toNumber());
//    case('U') : return(value);
//    case('I') : return(value);
      case('S') : return(value.toNumber());
      case('Z') : return(NaN);
      default   : return(value);
    }
    return(value);
  };

  BinaryTableClass.prototype.toArray = function(startRow, numRow) {
    if (startRow < 0) return(null);

    var ret = [], structure = this.structure;
    var i = startRow, max = startRow + numRow, l = structure.length;
    while((i < this.nrow) && (i < max)) {
      var entry = [], row = this.table[i];
      for(var j = 0; j < l; j++) {
        entry.push((structure[j].type != 'Z') ? row[j] : null);
      }
      ret.push(entry);
      i++;
    }
    for(i = ret.length; i < numRow; i++) {
      ret.push(null); // padding
    }
    
    return(ret);
  };

  BinaryTableClass.prototype.search = function() {
    var args = arguments.slice(0);

    var startRow    = args.shift();
    var resultArray = args.pop();
    var limitCount  = args.pop();
    var logic       = args.pop();
    if (args.length % 3) throw('[InvalidArguments] : not enough arguments');

    var conditionList = [];
    for(var i = 0, l = args.length / 3; i < l; i++) {
      conditionList.push({
        searchedColumn : args[i * 3 + 0],
        compared       : args[i * 3 + 1],
        operator       : args[i * 3 + 2]
      });
    }

    for(i = startRow, l = this.nrow; i < l; i++) {
      if (limitCount <= 0) break;

      var row = this.table[i], flag = true;
      for(var j = 0, m = conditionList.length; j < m; j++) {
        var condition = conditionList[j];
        var value     = row[condition.searchedColumn];
        var compared  = condition.compared;

        switch(condition.operator) {
          // Unsigned Integer or Signed Integer
          case( 0) : { flag = value == compared; } break;
          case( 1) : { flag = value != compared; } break;
          case( 2) : { flag = value <  compared; } break;
          case( 3) : { flag = value <= compared; } break;
          case( 4) : { flag = value >  compared; } break;
          case( 5) : { flag = value >= compared; } break;
          case( 6) : { flag = value &  compared; } break;
          case( 7) : { flag = value |  compared; } break;
          case( 8) : { flag = value ^  compared; } break;
          case( 9) : { flag = value & ~compared; } break;
          case(10) : { flag = value | ~compared; } break;
          case(11) : { flag = value ^ ~compared; } break;
          // String
          case(32) : { flag = value == compared;             } break;
          case(33) : { flag = value.indexOf(compared) >=  0; } break;
          case(34) : { flag = value.indexOf(compared) === 0; } break;
          case(35) : { flag =
            value.lastIndexOf(compared) == value.length - compared.length; } break;
          case(36) : { flag = value != compared;             } break;
          case(37) : { flag = value.indexOf(compared) <   0; } break;
          // Boolean
          case(64) : { flag = value == compared; } break;
          case(65) : { flag = value != compared; } break;
          // ZipCode
          case(96) : { flag =  includeZipCode(compared, value.include) &&
                              !includeZipCode(compared, value.exclude); } break;
          case(97) : { flag = !includeZipCode(compared, value.include) &&
                               includeZipCode(compared, value.exclude); } break;
          default  : { flag = true; } break;
        }
        if (!flag) break;
      }

      if (flag) resulutArray.push(row);
      limitCount--;
    }

    return((resultArray.length <=  0) ? NaN : (limitCount <= 0) ? --i : -1);
  };

  return(BinaryTableClass);
})();
