var _bml_start_time_ = (new Date).getTime();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
var BML = (typeof(BML) == 'undefined') ? {} : BML;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// ����
//   ��IE�ϲ��������ѤǤ��ʤ��Τ����б�(���λ����Ǿܺٸ�Ƥ̤)
//     - getter/setter��̤����
//     - XHR.overrideMimetype��̤����
//   ��Opera10.53(�ǿ��ǰ���)�Ǽ����Զ�礬�������б�
//     - XHR.overrideMimetype��ͭ����ư��ʤ����ᡤ�������б��Ǥ��ʤ�
//       = �Х��ʥ�ǡ���(CLUT)�������Ǥ��ʤ�
//       = �����ե������ʸ�������ɤ�(��񤭤Ǥ��ʤ�����)������ǧ���Ǥ��ʤ�
// ���б���
//   ��grayscale-color-index�����Ϥ��٤�̵��
//     - grayscale-color-index�����ˤ��ɽ������ϹԤ�ʤ�
//     - normalStyle.grayscaleColorIndex ��getter��default�ͤ��֤�
//     - normalStyle.grayscaleColorIndex ��setter��̤����
//   ��activeStyle / focusStyle �Ϥ��٤�̵��
//     - (activeStyle||focusStyle)��getter�Ϥ��٤�default�ͤ��֤�
//     - (activeStyle||focusStyle)��setter�Ϥ��٤�̤����
// ������ࡧ
//   ���桼�������Object����data�ץ��ѥƥ����Ѥ��ʤ�����
//     - ECMAScript���������.data��.dataInterface�˽񤭴������뤿��
// ��­��
//   ��safari(webkit)�ϳ���(src)���Ȥ���script���Ǥ�ưŪ��������ư��ʤ�
//     (script���Ǥ���������뤬ɾ������ʤ�)���ᡤ�����ե�������������script
//     ���Ǥ�ľ��script�򵭽Ҥ���
// ��뤳�ȡ�
//   ������ɽ���θ����󻲾Ȥι�θ(��Matcher)
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function(dst, src) { for(var key in src) { dst[key] = src[key]; } })(BML, {
  url         : '',
  version     : null,
  config      : {
    prefixScriptIncPath : ['../scripts/prefix.js'],
    suffixScriptIncPath : ['../scripts/suffix.js'],
    defaultFontName     : "'ARISAKA-����','IPA�����å�'",
    usableFontName      : {'ARISAKA-����' : 1, 'IPA�����å�' : 1 },
    debug               : true
  },
  bmlStyle    : {
    resolution          : '960x540',
    displayAspectRatio  : '16v9',
    usedKeyList         : 'basic data-button'
  }
});
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() {
  ///////////////////////////////////////////////////////////////////////////////////////////
  // ̤������BML��ϢClass��
  BML.Bevent = {
    entry : function(property) {},
    clear : function() {}
  };
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // Utility�ؿ���
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var slice       = Array.prototype.slice;
  var isIE        = !!(window.attachEvent && (navigator.userAgent.indexOf('opera') === -1));
  var isOpera     = Object.prototype.toString.call(window.opera) == '[object Opera]';
  var isSafari    = navigator.userAgent.indexOf('AppleWebKit/') > -1;
  var $break      = {};
  var uriMatcher  = /^(?:(https?:\/\/[^\/]+\/)((?:[^\/]*\/)*))((?:([^\?\#]*)\.([^\.\?\#]*))|([^\?\#\.]*))?(?:\?([^\#]*))?(?:#(.*))?/;
  function emptyFunction()   { }
  function getClass(obj)     { return(Object.prototype.toString.call(obj).match(/^\[object\s(.*)\]$/)[1]); }
  function isArray(obj)      { return(getClass(obj) == 'Array'); }
  function isUndefined(obj)  { return(typeof(obj) == 'undefined'); }
  function extend(dst, src)  { for(k in src) { dst[k] = src[k]; } return(dst); }
  function append(array) {
    var thisLength = this.length, length = array.length;
    while(length--) this[thisLength + length] = array[length];
    return(this);
  }
  function bind(context) {
    if ((arguments.length < 2) && isUndefined(arguments[0])) return(this);
    
    var __method = this, args = slice.call(arguments, 1);
    return(function() {
      var a = append.call(slice.call(args, 0), arguments);
      return(__method.apply(context, a));
    });
  }
  function wait(timeout, context) {
    var __method = this, args = slice.call(arguments, 2);
    return(window.setTimeout(function() {
      return(__method.apply(context, args));
    }, timeout * 1000));
  }
  function each(iterator, context) {
   context = context || this;
    try {
      for(var i = 0, l = this.length; i < l; i++) {
        iterator.call(context, this[i], i);
      }
    } catch(e) {
      if (e != $break) throw(e);
    }
    return(this);
  }
  function hashEach(iterator, context) {
    context = context || this;
    try {
      for(var key in this) {
        iterator.call(context, key, this[key]);
      }
    } catch(e) {
      if (e != $break) throw(e);
    }
    return(this);
  }
  function parseURI(uri) {
    if (!uri) return(null);

    var org = uri;
    uri = uri.replace(/\\/g, '/');
    var match = uriMatcher.exec(uri);
    
    return(match ? {
      host     : match[1] || '',
      path     : match[2] || '',
      file     : match[3] || '',
      name     : match[4] || match[6] || '',
      ext      : match[5] || '',
      query    : match[7] || '',
      fragment : match[8] || ''} : null);
  }
  function combinePath(src, current) {
    if (src.indexOf('http') >= 0) return(src);
    var p = parseURI(current);
    return(p.host+p.path+src);
  }
  function toPaddedNumber(n, p, l) {
    var str = ''; n = String(n); p = p || ' ';
    for(var i = n.length, len = l || 2; i < len; i++) str += p;
    return(str + n);
  }
  function toColorCode(r, g, b) {
    return(toPaddedNumber(Number(r).toString(16), '0')+
           toPaddedNumber(Number(g).toString(16), '0')+
           toPaddedNumber(Number(b).toString(16), '0'));
  }
  function camelize(str) {
    var parts = str.split('-');
    if (parts.length <= 1) return(str);

    var buf = String(parts[0]).toLowerCase();
    for(var i = 1, l = parts.length; i < l; i++) {
      var part = String(parts[i]);
      if (!part) continue;
      part = part.toLowerCase();
      buf += part.charAt(0).toUpperCase() + part.substring(1);
    }
    return(buf);
  }
  function hashToString(obj) {
    var s = '';
    for(var k in obj) { s += '['+k+':'+obj[k]+'] '; }
    return(s);
  }
  function getStyle(node, style) {
    var value = node.style[style];
    if (!value || (value == 'auto')) {
      var css = node.currentStyle || document.defaultView.getComputedStyle(node, null);
      value = css ? css[style] : null;
    }
    return((value == 'auto')? null : value);
  }
  var supportSpecificElement = !(isUndefined(window.HTMLSpanElement));

  BML.Util = {
    $break         : $break,
    isIE           : isIE,
    isOpera        : isOpera,
    isSafari       : isSafari,
    emptyFunction  : emptyFunction,
    isArray        : isArray,
    isUndefined    : isUndefined,
    extend         : extend,
    bind           : bind,
    wait           : wait,
    each           : each,
    hashEach       : hashEach,
    parseURI       : parseURI,
    combinePath    : combinePath,
    toPaddedNumber : toPaddedNumber,
    toColorCode    : toColorCode,
    camelize       : camelize,
    hashToString   : hashToString,
    getStyle       : getStyle,
    supportSpecificElement : supportSpecificElement
  };
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // Ajax��Ϣ
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var util = BML.Util;
  function toQueryPair(k, v) { return(util.isUndefined(v)? k : k+'='+encodeURIComponent(v===null? '' : v)); }
  function getTransport() {
    var transport = ['XMLHttpRequest()',
                     "ActiveXObject('Msxml2.XMLHTTP')",
                     "ActiveXObject('Microsoft.XMLHTTP')"];
    for(var i = 0, l = transport.length; i < l; i++) {
      try      { return(eval('new ' + transport[i])); }
      catch(e) { }
    }
    return(null);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var ajax = function(url, options) {
    this._complete = false;
    
    this.options = util.extend({
      method       : 'POST',
      asynchronous : true,
      contentType  : 'application/x-www-form-urlencoded',
      encoding     : 'UTF-8',
      parameters   : '',
      postBody     : ''
    }, options || {});
    this.method    = this.options.method.toUpperCase() || 'POST';
    this.transport = getTransport();

    if (url) this.request(url);
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.request = function(url) {
    if (!url) return;

    this.url       = url;
    this.accessUrl = url;
    this.query     = '';
    this.body      = null;

    var p = [], params = this.options.parameters || {}, val;
    for(var key in params) {
      val = params[key];
      key = encodeURIComponent(key);
      if (isArray(val)) {
        util.each.call(val, function(v) { p.push(toQueryPair(key, v)); });
      } else {
        p.push(toQueryPair(key, val));
      }
    }
    this.query = p.join('&');

    if ((this.method == 'GET') && (this.query.length > 0))  {
      this.accessUrl += ((url.indexOf('?') > 0) ? '&' : '?') + this.query;
    } else {
      if (/Konqueror|Safari|KHTML/.test(navigator.userAgent)) this.query += '&_=';
      this.body = this.options.postBody || this.query;
    }

    try {
      var transport = this.transport;
      if (this.options.overrideMimeType && transport.overrideMimeType)
        transport.overrideMimeType(this.options.overrideMimeType);
      transport.open(this.method, this.accessUrl, this.options.asynchronous);
      if (this.options.asynchronous) util.wait.call(this.respondToReadyState, 0.01, this, 1);

      transport.onreadystatechange = util.bind.call(this.onStateChange, this);
      var headers = this.getRequestHeaders();
      for(key in headers) transport.setRequestHeader(key, headers[key]);

      transport.send(this.body);
      if (!this.options.asynchronous && transport.overrideMimeType) this.onStateChange();

      BML.Debug('[ajax]:'+this.accessUrl);
    } catch(e) {
      this.dispatchException(e);
    }
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.onStateChange = function() {
    var readyState = this.transport.readyState;
    if ((readyState > 1) && ((readyState != 4) || !this._complete))
      this.respondToReadyState(readyState);
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.respondToReadyState = function(readyState) {
    var state    = ajax.Events[readyState];
    var response = new ajax.Response(this);

    try {
      (this.options['on' + state] || util.emptyFunction)(response);
    } catch(e) {
      this.dispatchException(e);
    }

    if (state == 'Complete') {
      try {
        this._complete = true;
        (this.options['on' + response.statusCode] ||
         this.options['on' + (this.success() ? 'Success' : 'Failure')] ||
         util.emptyFunction)(response);
      } catch(e) {
        this.dispatchException(e);
      }

      this.transport.onreadystatechange = util.emptyFunction;
    }
    this.response = response;
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.success = function() {
    var status = this.getHttpStatusCode();
    return(!status || ((status >= 200) && (status < 300)));
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.getRequestHeaders = function() {
    var headers = {
      'X-Requested-With' : 'XMLHttpRequest',
      'Accept'           : "text/javascript, text/html, application/xml, text/xml, */*"
    };
    if (this.method == 'POST') {
      headers['Content-type'] = this.options.contentType +
        (this.options.encoding ? '; charset=' + this.options.encoding : '');
      // Force "Connection: close" for older Mozilla browsers to work. see Mozilla Bugzilla #246651.
      if (this.transport.overrideMimeType &&
          (navigator.userAgent.match(/Gecko\/(\d{4})/) || [0,2005])[1] < 2005)
            headers['Connection'] = 'close';
    }

    return(headers);
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.getHttpStatusCode = function()     { try { return(this.transport.status || 0); } catch(e) { return(0); } };
  ajax.prototype.getHeader         = function(name) { try { return(this.transport.getResponseHeader(name) || null); } catch(e) { return(null); } };
  ajax.prototype.getAllHeaders     = function()     { try { return(this.transport.getAllResponseHeaders() || null); } catch(e) { return(null); } };
  ajax.prototype.dispatchException = function(e)    { (this.options.onError || util.emptyFunction)(this, e); };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var response = function(request) {
    this.status     = 0;
    this.statusText = '';
    this.request    = request;
    var transport   = this.transport  = request.transport;
    var readyState  = this.readyState = transport.readyState;

    if (((readyState > 2) && !util.isIE) || (readyState == 4)) {
      this.statusCode   = this._getHttpStatusCode();
      this.statusText   = this._getStatusText();
      this.responseText = (transport.responseText === null) ? '' : transport.responseText;
    }

    if (readyState == 4) {
      var xml = transport.responseXML;
      this.responseXML = util.isUndefined(xml) ? null : xml;
    }
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  response.prototype._getHttpStatusCode     = ajax.prototype.getHttpStatusCode;
  response.prototype._getResponseHeader     = ajax.prototype.getHeader;
  response.prototype._getAllResponseHeaders = ajax.prototype.getAllHeaders;
  response.prototype._getStatusText         = function() { try { return(this.transport.statusText || ''); } catch(e) { return(''); } };

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.Events = ['Uninitialized', 'Loading', 'Loaded', 'Interactive', 'Complete'];
  ajax.Response = response;
  
  BML.Ajax = ajax;
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
BML.Debug = (function() {
  var startTime  = _bml_start_time_; delete(_bml_start_time_);
  var prevTime   = startTime;
  var plane      = null;
  var bgPlane    = null;
  var maxline    = 20;
  var strBuf     = [];
  var count      = 0;
  var visible    = true;
  var entryEvent = false;
  var level      = { debug : false, info : true, warn : true, error : true };
  function initialize() {
    if (plane) return;

    var body = document.getElementsByTagName('body');
    if (body.length > 0) {
      bgPlane = document.createElement('div');
      bgPlane.setAttribute('id', '_bml_debug_bgplane_');
      bgPlane.style.visibility = visible ? 'visible' : 'hidden';

      plane = document.createElement('div');
      plane.setAttribute('id', '_bml_debug_plane_');
      plane.style.visibility = visible ? 'visible' : 'hidden';

      body[0].appendChild(bgPlane);
      body[0].appendChild(plane);

      document.addEventListener('keydown', function(event) {
        if (event.keyCode == 0x1b) {
          visible = !visible;
          bgPlane.style.visibility = visible ? 'visible' : 'hidden';
          plane.style.visibility   = visible ? 'visible' : 'hidden';
          event.cancelBubble = true;
        }
      }, false);
      BML.Debug.info('[BML.Debug initialized]');
      draw();
    } else if (!entryEvent) {
      window.addEventListener('load', arguments.callee, false);
      entryEvent = true;
    }
  }
  function draw() {
    if (plane && visible) plane.innerHTML = (BML.config.debug) ? strBuf.join("<br/>\n") : '';
  }
  function show() { visible = true;  if (plane) bgPlane.style.visibility = plane.style.visibility = 'visible'; draw(); }
  function hide() { visible = false; if (plane) bgPlane.style.visibility = plane.style.visibility = 'hidden';  draw(); }
  function debug(msg) { write(msg, 'debug'); }
  function write(msg, type) {
    type = type || 'debug';
    if (level[type]) {
      var toPNum = BML.Util.toPaddedNumber;
      var t = prevTime; prevTime = (new Date).getTime();
      var dmsg = '['+toPNum(count++, '&#160;', 4)+']('+toPNum(prevTime - t, '&#160;', 5)+'ms)'+msg;
      var cmsg = '['+toPNum(count++, ' ',      4)+']('+toPNum(prevTime - t, ' ',      5)+'ms)'+msg;
      if (!BML.Util.isUndefined(window.console) &&
          !BML.Util.isUndefined(window.console[type])) window.console[type](cmsg);
      strBuf.push('<span class="_bml_debug_'+type+'_">'+dmsg+'</span>');
      if (strBuf.length > maxline) strBuf.shift();
      draw();
    }
  }
  function reset() { strBuf = []; count = 0; show(); }
  function setDebugLevel(type, bool) { level[type] = bool || false; }
  function getLoadStartTime() { return(startTime); }

  debug.initialize       = initialize;
  debug.reset            = reset;
  debug.info             = function(msg) { write(msg, 'info');  };
  debug.warning          = function(msg) { write(msg, 'warn');  };
  debug.error            = function(msg) { write(msg, 'error'); };
  debug.setDebugLevel    = setDebugLevel;
  debug.getLoadStartTime = getLoadStartTime;
  
  return(debug);
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
BML.Clut = (function() { // CLUT��Ϣ
  var palette = [
    // ARIB TR-B14 �軰�ԡ���2�� ��Ͽ1 ���������̸��꿧�׻���
    [  0,  0,  0,255,'000000'], [255,  0,  0,255,'ff0000'], [  0,255,  0,255,'00ff00'], [255,255,  0,255,'ffff00'],
    [  0,  0,255,255,'0000ff'], [255,  0,255,255,'ff00ff'], [  0,255,255,255,'00ffff'], [255,255,255,255,'ffffff'],
    [  0,  0,  0,  0,'000000'],
    [170,  0,  0,255,'aa0000'], [  0,170,  0,255,'00aa00'], [170,170,  0,255,'aaaa00'], [  0,  0,170,255,'0000aa'],
    [170,  0,170,255,'aa00aa'], [  0,170,170,255,'00aaaa'], [170,170,170,255,'aaaaaa'], [  0,  0, 85,255,'000055'],
    [  0, 85,  0,255,'005500'], [  0, 85, 85,255,'005555'], [  0, 85,170,255,'0055aa'], [  0, 85,255,255,'0055ff'],
    [  0,170, 85,255,'00aa55'], [  0,170,255,255,'00aaff'], [  0,255, 85,255,'00ff55'], [  0,255,170,255,'00ffaa'],
    [ 85,  0,  0,255,'550000'], [ 85,  0, 85,255,'550055'], [ 85,  0,170,255,'5500aa'], [ 85,  0,255,255,'5500ff'],
    [ 85, 85,  0,255,'555500'], [ 85, 85, 85,255,'555555'], [ 85, 85,170,255,'5555aa'], [ 85, 85,255,255,'5555ff'],
    [ 85,170,  0,255,'55aa00'], [ 85,170, 85,255,'55aa55'], [ 85,170,170,255,'55aaaa'], [ 85,170,255,255,'55aaff'],
    [ 85,255,  0,255,'55ff00'], [ 85,255, 85,255,'55ff55'], [ 85,255,170,255,'55ffaa'], [ 85,255,255,255,'55ffff'],
    [170,  0, 85,255,'aa0055'], [170,  0,255,255,'aa00ff'], [170, 85,  0,255,'aa5500'], [170, 85, 85,255,'aa5555'],
    [170, 85,170,255,'aa55aa'], [170, 85,255,255,'aa55ff'], [170,170, 85,255,'aaaa55'], [170,170,255,255,'aaaaff'],
    [170,255,  0,255,'aaff00'], [170,255, 85,255,'aaff55'], [170,255,170,255,'aaffaa'], [170,255,255,255,'aaffff'],
    [255,  0, 85,255,'ff0055'], [255,  0,170,255,'ff00aa'], [255, 85,  0,255,'ff5500'], [255, 85, 85,255,'ff5555'],
    [255, 85,170,255,'ff55aa'], [255, 85,255,255,'ff55ff'], [255,170,  0,255,'ffaa00'], [255,170, 85,255,'ffaa55'],
    [255,170,170,255,'ffaaaa'], [255,170,255,255,'ffaaff'], [255,255, 85,255,'ffff55'], [255,255,170,255,'ffffaa'],
    [  0,  0,  0,128,'000000'], [255,  0,  0,128,'ff0000'], [  0,255,  0,128,'00ff00'], [255,255,  0,128,'ffff00'],
    [  0,  0,255,128,'0000ff'], [255,  0,255,128,'ff00ff'], [  0,255,255,128,'00ffff'], [255,255,255,128,'ffffff'],
    [170,  0,  0,128,'aa0000'], [  0,170,  0,128,'00aa00'], [170,170,  0,128,'aaaa00'], [  0,  0,170,128,'0000aa'],
    [170,  0,170,128,'aa00aa'], [  0,170,170,128,'00aaaa'], [170,170,170,128,'aaaaaa'], [  0,  0, 85,128,'000055'],
    [  0, 85,  0,128,'005500'], [  0, 85, 85,128,'005555'], [  0, 85,170,128,'0055aa'], [  0, 85,255,128,'0055ff'],
    [  0,170, 85,128,'00aa55'], [  0,170,255,128,'00aaff'], [  0,255, 85,128,'00ff55'], [  0,255,170,128,'00ffaa'],
    [ 85,  0,  0,128,'550000'], [ 85,  0, 85,128,'550055'], [ 85,  0,170,128,'5500aa'], [ 85,  0,255,128,'5500ff'],
    [ 85, 85,  0,128,'555500'], [ 85, 85, 85,128,'555555'], [ 85, 85,170,128,'5555aa'], [ 85, 85,255,128,'5555ff'],
    [ 85,170,  0,128,'55aa00'], [ 85,170, 85,128,'55aa55'], [ 85,170,170,128,'55aaaa'], [ 85,170,255,128,'55aaff'],
    [ 85,255,  0,128,'55ff00'], [ 85,255, 85,128,'55ff55'], [ 85,255,170,128,'55ffaa'], [ 85,255,255,128,'55ffff'],
    [170,  0, 85,128,'aa0055'], [170,  0,255,128,'aa00ff'], [170, 85,  0,128,'aa5500'], [170, 85, 85,128,'aa5555'],
    [170, 85,170,128,'aa55aa'], [170, 85,255,128,'aa55ff'], [170,170, 85,128,'aaaa55'], [170,170,255,128,'aaaaff'],
    [170,255,  0,128,'aaff00'], [170,255, 85,128,'aaff55'], [170,255,170,128,'aaffaa'], [170,255,255,128,'aaffff'],
    [255,  0, 85,128,'ff0055'], [255,  0,170,128,'ff00aa'], [255, 85,  0,128,'ff5500'], [255, 85, 85,128,'ff5555'],
    [255, 85,170,128,'ff55aa'], [255, 85,255,128,'ff55ff'], [255,170,  0,128,'ffaa00'], [255,170, 85,128,'ffaa55'],
    [255,170,170,128,'ffaaaa'], [255,170,255,128,'ffaaff'], [255,255, 85,128,'ffff55']
  ];
  var codeToIdx = {};
  BML.Util.each.call(palette, function(entry, idx) {
    if (!codeToIdx[entry[4]]) codeToIdx[entry[4]] = idx;
  });
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  return({
    load : function(url) {
      var ajax = new BML.Ajax(url, {
        overrideMimeType : 'text/plain; charset=x-user-defined',
        asynchronous     : false,
        method           : 'GET'
      });
      var bytes = [];
      var stream = ajax.response.responseText;
      for(var i = 0, l = stream.length; i < l; i++) {
        bytes[i] = stream.charCodeAt(i) & 0x00ff;
      }
      
      var flags  = bytes.shift();
      var sIdx   = bytes.shift();
      var eIdx   = bytes.shift();
      var toCode = BML.Util.toColorCode;
      while(sIdx <= eIdx) {
        var y  = bytes.shift();
        var cb = bytes.shift();
        var cr = bytes.shift();
        var r  = Math.floor(1.164 * (y-16)                    + 1.596 * (cr-128));
        var g  = Math.floor(1.164 * (y-16) - 0.391 * (cb-128) - 0.813 * (cr-128));
        var b  = Math.floor(1.164 * (y-16) + 2.018 * (cb-128));
        r = Math.max(0, Math.min(255, r));
        g = Math.max(0, Math.min(255, g));
        b = Math.max(0, Math.min(255, b));

        var code        = toCode(r,g,b);
        palette[sIdx]   = [r, g, b, bytes.shift(), code];
        codeToIdx[code] = sIdx++;
      }
    },
    getColorCode : function(idx) {
      return(((idx < 0) || (idx >= palette.length) || !palette[idx]) ?
             '000000' : palette[idx][4]);
    },
    getRGB : function(idx) {
      return(((idx < 0) || (idx >= palette.length)) ?
             { r : 0, g : 0, b : 0, a : 0 } :
             (function() {
             var p = palette[idx];
             return({ r : p[0], g : p[1], b : p[2], a : p[3] });
           })());
    },
    codeToIdx : function(code) {
      var idx = codeToIdx[code.toLowerCode()];
      return((idx >= 0)? idx : -1);
    }
  });
})();

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
BML.UsedKeyList = (function() { // usedKeyList��Ϣ
  var keyList = {
    'basic'          : [  1,  2,  3,  4, 18, 19 ],    // ��,��,��,��,����,���
    'data-button'    : [ 21, 22, 23, 24 ],            // ��,��,��,��,d
    'numeric-tuning' : [  5,  6,  7,  8,  9, 10,      // 0,1,2,3,4,5,6
                       11, 12, 13, 14, 15, 16, 17], // 7,8,9,10,11,12
    'other-tuning'   : [],
    'special-1'      : [],
    'special-2'      : [],
    'special-3'      : [],
    'special-4'      : [],
    'misc'           : []
  };
  var keyHash = {};
  function set(list) {
    BML.bmlStyle.usedKeyList = list;
    list = list.split(/\s+/);
    BML.Util.each(list, function(a) {
      BML.Debug.error(a);
    });
  }

  set(BML.bmlStyle.usedKeyList);
  
  return({
    set         : set,
    isValidCode : function(node) {}
  });
})();

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
BML.Navigation = (function() { // Navigation��Ϣ
  ///////////////////////////////////////////////////////////////////////////////////////////
 var keycode = {
    // see: ARIB-B24 Appendix.2 5.1.8
     38 :  1, 40 :  2, 37 :  3, 39 :  4,  // up(��),down(��),left(��),right(��)
     48 :  5, 49 :  6, 50 :  7, 51 :  8,  //  0(0), 1(1), 2(2), 3(3),
     52 :  9, 53 : 10, 54 : 11, 55 : 12,  //  4(4), 5(5), 6(6), 7(7),
     56 : 13, 57 : 14,109 : 15,222 : 16,  //  8(8), 9(9),10(-),11(^),
    220 : 17,                             // 12(\)
     13 : 18, 88 : 18,  8 : 19, 68 : 20,  // Enter(Return/x),Back(BS),d-Button(d)
     66 : 21, 82 : 22, 71 : 23, 89 : 24   // B(b),R(r),G(g),Y(y)
  };
  var navIdxToElement    = [];
  var accessKeyToElement = {};
  var focusableElement   = [];
  function initialize() {
    var elm, key, i;
    for(i = 0, l = navIdxToElement.length; i < l; i++) {
      elm = navIdxToElement[i];
      if (elm) break;
    }
    if (!elm && (focusableElement.length > 0)) {
      elm = focusableElement[0];
    }
    if (!elm && (accessKeyToElement.length > 0)) {
      key = []; for(i in accessKeyToElement) { key.push(i); } key = key.sort();
      elm = key[0];
    }
    if (elm) elm.focus();///////////////////eee
  }
  function grabInput()    { document.addEventListener('keydown', processEvent, true); BML.Debug('[grab input]'); }
  function releaseInput() { document.removeEventListener('keydown', processEvent); BML.Debug('[release input]'); }
  function processEvent(event) {
//    BML.Debug(event);
  }
  
  return({
    initialize   : initialize,
    grabInput    : grabInput,
    releaseInput : releaseInput,
    addNavIndex  : function(elm, idx) { navIdxToElement[idx]    = elm; },
    addAccessKey : function(elm, key) { accessKeyToElement[key] = elm; },
    addFocusable : function(elm)      { focusableElement.push(elm);    },
    focus        : function(elm)      { },//BML.Debug.info(elm.nodeName+"("+elm.id+")"); },
    blur         : function(elm)      { }//BML.Debug.info(elm.nodeName+"("+elm.id+")"); }
  });
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // normalStyle/activeStyle/focusStyle/focus/blur��Ϣ
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var getStyle = BML.Util.getStyle;
  var supportSpecificElement = BML.Util.supportSpecificElement;
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var normalStyleTargets = supportSpecificElement ?
    [ 'HTMLDivElement',    'HTMLSpanElement',  'HTMLParagraphElement', 'HTMLBRElement',
      'HTMLAnchorElement', 'HTMLInputElement', 'HTMLObjectElement',    'HTMLBodyElement' ] :
    ['HTMLElement'];
  var cssPseudoClassStyleTargets = supportSpecificElement ?
    [ 'HTMLDivElement',    'HTMLSpanElement',  'HTMLParagraphElement',
      'HTMLAnchorElement', 'HTMLInputElement', 'HTMLObjectElement' ] :
    ['HTMLElement'];
  var focusBlurTargets = supportSpecificElement ?
    [ 'HTMLDivElement',    'HTMLSpanElement',  'HTMLParagraphElement', 
      'HTMLAnchorElement', 'HTMLInputElement', 'HTMLObjectElement' ] :
    ['HTMLElement'];
  
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // pseudo normalStyle Object
  function normalStyleObj(node) {
    this.node = node;
    if (!node._bmlStyle) node._bmlStyle = {};
  }
  BML.Util.each.call([// read only property
   'paddingTop',  'paddingBottom', 'paddingLeft', 'paddingRight',
   'borderWidth', 'borderStyle',
   'lineHeight',  'textAlign',     'letterSpacing'
  ], function(key) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      return(this.node.style[key]);
    });
  });
  
  BML.Util.each.call([ // readable/writable property
    'left',       'top',        'width',    'height',
    'visibility', 'fontFamily', 'fontSize', 'fontWeight'
  ], function(key) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      return(getStyle(this.node, key));
    });
    normalStyleObj.prototype.__defineSetter__(key, (function(k) {
      return(function(v) { this.node.style[k] = v; });
    })(key));
  });

  BML.Util.each.call([
    'clut',  'resolution', 'displayAspectRatio',
    'navUp', 'navDown',    'navLeft', 'navRight', 'navIndex'
  ], function(key) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      return((this.node.nodeName.toLowerCase() == 'body') ?
             BML.bmlStyle[key] : this.node._bmlStyle[key]);
    });
  });
  
  BML.Util.hashEach.call({
    usedKeyList : function(key) { return(function(val) {
      BML.UsedKeyList.set(val);
    }); }
  }, function(key, val) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      return((this.node.nodeName.toLowerCase() == 'body') ?
             BML.bmlStyle[key] : this.node._bmlStyle[key]);
    });
    normalStyleObj.prototype.__defineSetter__(key, val(key));
  });

  BML.Util.each.call([
    'borderTopColorIndex',  'borderRightColorIndex',
    'borderLeftColorIndex', 'borderbottomColorIndex',
    'backgroundColorIndex', 'colorIndex'
  ], function(key) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      var color = getStyle(this.node, key.substring(0, key.length - 5));
      if (/rgb\((\d+)[^\d]+(\d+)[^\d]+(\d+)\)/.test(color)) {
        color = BML.Util.toColorCode(RegExp.$1, RegExp.$2, RegExp.$3);
      }
      return(BML.Clut.codeToIdx(color));
    });
    normalStyleObj.prototype.__defineSetter__(key, function(val) {
      this.node.style[key.substring(0, key.length - 5)] = val;
    });
  });
  normalStyleObj.prototype.__defineGetter__('grayscaleColorIndex', function() {
    return('30 15'); // return default value
  });
  normalStyleObj.prototype.__defineSetter__('grayscaleColorIndex', function(val) {
  });

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // pseudo fucusStyle / active Object
  var cssPseudoClassStyleObj = {
    left : 0, top  : 0, width : 0, height : 0, visibility : 'inherit',
    fontFamily : BML.config.defaultFontName, fontSize  : '24px', fontWeight : 'normal',
    colorIndex : 0, backgroundColorIndex : 0,
    borderTopColorIndex : 0, borderBottomColorIndex : 0,
    borderRightColorIndex : 0, borderLeftColorIndex : 0,
    grayscaleColorIndex : 0
  };

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  BML.Util.each.call(normalStyleTargets, function(elm) {
    try {
      eval(elm).prototype.__defineGetter__('normalStyle', function() {
        if (!this._normalStyleObj) this._normalStyleObj = new normalStyleObj(this);
        return(this._normalStyleObj);
      });
    } catch(e) {
      BML.Debug.error(e);
    }
  });
  BML.Util.each.call(cssPseudoClassStyleTargets, function(elm) {
    try {
      eval(elm).prototype.__defineGetter__('focusStyle',  function() {
        if (!this._focusStyleObj)  this._focusStyleObj  = BML.Util.extend({}, cssPseudoClassStyleObj);
        return(this._focusStyleObj);
      });
      eval(elm).prototype.__defineGetter__('activeStyle', function() {
        if (!this._activeStyleObj) this._activeStyleObj = BML.Util.extend({}, cssPseudoClassStyleObj);
        return(this._activeStyleObj);
      });
    } catch(e) {
      BML.Debug.error(e);
    }
  });
  BML.Util.each.call(focusBlurTargets, function(elm) {
    try {
      eval(elm).prototype.focus = function() { BML.Navigation.focus(this); };
      eval(elm).prototype.blur  = function() { BML.Navigation.blur (this); };
    } catch(e) {
      BML.Debug.error(e);
    }
  });
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
BML.Builder = (function() { // bmlʸ��ϥ�ɥ��Ϣ
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var NODETYPE = {
    UNKNOWN_NODE           :  0,
    ELEMENT_NODE           :  1,
    ATTRIBUTE_NODE         :  2,
    TEXT_NODE              :  3,
    CDATA_SECTION_NODE     :  4,
    ENTITY_REFERENCE_NODE  :  5,
    ENTITY_NODE            :  6,
    PROC_INSTRUCTION_NODE  :  7,
    COMMENT_NODE           :  8,
    DOCUMENT_NODE          :  9,
    DOCUMENT_TYPE_NODE     : 10,
    DOCUMENT_FRAGMENT_NODE : 11,
    NOTATION_NODE          : 12
  };
  var MIME_TYPE = {
    'image/jpeg'                            : 'image/jpeg',
    'image/X-arib-png'                      : 'image/png', 
    'image/X-arib-mng'                      : 'video/mng',
    'audio/X-arib-mpeg2-aac'                : null,
    'audio/X-arib-aiff'                     : 'audio/aiff',
    'application/X-arib-contentPlayControl' : null,
    'application/X-aribmpeg2-tts'           : null
  };
  var DTD_DECLARATIONS    = [
    ['-//ARIB STD-B24:1999//DTD BML Document for IPTV//JA', 'http://www.arib.or.jp/B24/DTD/bml_x_x_iptv.dtd', '100.0'], // IPTVFJ
    ['+//ARIB STD-B24:1999//DTD BML Document//JA',          'http://www.arib.or.jp/B24/DTD/bml_1_1.dtd',      '3.0']    // B-14
  ];
  var isFirstScript       = true;
  var isFirstInnerScript  = true;
  var clutMatcher         = /([^\w])clut[^\w:]*:[^\w]*(url\([^\w]*([^\)\s]+\s*)\));?/m;
  var usedKeyListMatcher  = /([^\w])used-key-list[^\w:]*:\s*([^;\}\s]+)\s*;?/m;
  var resolutionMatcher   = /([^\w])resolution[^\w:]*:([^;\}]+);?/mg;
  var aspectRatioMatcher  = /([^\w])display-aspect-ratio[^\w:]*:\s*([^;\}\s]+)\s*;?/mg;
  var grayscaleMatcher    = /([^\w])grayscale-color-index[^\w:]*:[^;\}]+;?/mg;
  var colorIndexMatcher   = /color-index[^\w:]*:\s*(\d+)(?:\s+(?:\d+))?/m;
  var fontFamilyMatcher   = /([^\w])font-family[^\w:]*:\s*([^\s;\}]+)\s*;?/m;
  var navAttributeMatcher = /(nav-\w+)[^:]*:[^\d]*(\d+)[^\w;\}]*;?/m;
  var reservedNameFuncs   = {};
  var rnOnloadMatcher     = /([^\w]function[^\w]+onload)([^\w])/m;
  var rnOnunloadMatcher   = /([^\w]function[^\w]+onunload)([^\w])/m;
  var eventHandlers       = {};
  var bodyElement         = null;
  var scriptBuffer        = null;

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function setCssStyle(node, style) {
    if (BML.Util.isIE) node.style.cssText = style;
    else               node.setAttribute('style', style);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function getFirstElementByTagName(name, node) {
    if (!node) return(null);
    var children = node.getElementsByTagName(name);
    return((children.length > 0) ? children[0] : null);
  }
  function fixScript(script) {
    if (!script) return('');

    if (BML.Util.isSafari) {
      script = script.replace(/\.data([^\w])/g, "\.dataInterface$1");
    }

    // avoid reserved words
    if (rnOnloadMatcher.test(script)) {
      script = RegExp.leftContext + RegExp.$1 + '_mod' + RegExp.$2 + RegExp.rightContext;
      reservedNameFuncs['onload']   = 'onload_mod';
    }
    if (rnOnunloadMatcher.test(script)) {
      script = RegExp.leftContext + RegExp.$1 + '_mod' + RegExp.$2 + RegExp.rightContext;
      reservedNameFuncs['onunload'] = 'onunload_mod';
    }

    return(script);
  }
  function stripEventHandlerString(str) { // 'hoge();'->'hoge'
    return(str.replace(/^\s*([^\s\(]+)\([^\)]*\)\s*;/, "$1"));
  }
  function colorIndexToColorCode(style) {
    var buf = '';
    while(1) {
      if (!colorIndexMatcher.test(style)) break;
      buf  += RegExp.leftContext + 'color:#' + BML.Clut.getColorCode(RegExp.$1);
      style = RegExp.rightContext;
    }
    return(buf + style);
  }
  function processStyle(style, elm) {
    style = style.replace(grayscaleMatcher,  "$1");

    if (!elm || (String(elm.nodeName).toLowerCase() == 'body')) {
     if (clutMatcher.test(style)) {
       style = RegExp.leftContext + RegExp.$1 + RegExp.rightContext;
       var p = RegExp.$2, f = RegExp.$3;
       BML.bmlStyle['clut'] = RegExp.$2;
       BML.Clut.load(RegExp.$3);
       BML.Debug.info('[CLUT:'+p+'] -> BML.Clut.load('+f+')');
      }
      if (usedKeyListMatcher.test(style)) {
        style = RegExp.leftContext + RegExp.$1 + RegExp.rightContext;
        var k = RegExp.$2;
        BML.bmlStyle['usedKeyList'] = RegExp.$2;
        BML.UsedKeyList.set(RegExp.$2);
        BML.Debug.info('[UsedKeyList:'+k+']');
      }
      if (aspectRatioMatcher.test(style)) {
        style = RegExp.leftContext + RegExp.$1 + RegExp.rightContext;
        var a = RegExp.$2;
        BML.bmlStyle['displayAspectRatio'] = RegExp.$2;
      }
      style = style.replace(resolutionMatcher, "$1");
    }

    if (elm) {
      // get nav-xxx
      var buf = '', nav = {}, camelize = BML.Util.camelize;
      while(1) {
        if (!navAttributeMatcher.test(style)) break;
        nav[camelize(RegExp.$1)] = RegExp.$2;
        buf  += RegExp.leftContext;
        style = RegExp.rightContext;
      }
      style = buf + style;
      
      if (!elm._bmlStyle) elm._bmlStyle = {};
      BML.Util.extend(elm._bmlStyle, nav);
      if (nav['navIndex'] >= 0) BML.Navigation.addNavIndex(elm, nav['navIndex']);
    }
      
    if (fontFamilyMatcher.test(style) && !BML.config.usableFontName[RegExp.$2]) {
      style = RegExp.leftContext + RegExp.$1 + RegExp.rightContext;
    }
    style = colorIndexToColorCode(style);

    return(style);
  }
  function getExternalScript(src) {
    src = BML.Util.combinePath(src, BML.url);
    var ajax = new BML.Ajax(src, {
      overrideMimeType : 'application/javascript; charset=EUC-JP',
      asynchronous     : false,
      method           : 'GET'
    });
    return('//'+src+"\n" + fixScript(ajax.response.responseText));
  }

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function setDefaultAttributes(elm, prop) {
    for(var k in prop) { elm.setAttribute(k, prop[k]); }
    return(elm);
  }
  function setCoreAttributes(elm, ref) {
    var tmp;
    tmp = ref.getAttribute('id');    if (tmp) elm.setAttribute('id',    tmp);
    tmp = ref.getAttribute('class'); if (tmp) elm.setAttribute('class', tmp);
    return(elm);
  }
  function setI18nAttributes(elm, ref) {
    elm.setAttribute('xml:lang', 'ja');
    return(elm);
  }
  function setStyleAttributes(elm, ref) {
    var style = ref.getAttribute('style');
    if (!style) return(elm);

    setCssStyle(elm, processStyle(style, elm));
    return(elm);
  }
  function setScriptAttributes(elm, srcUri) {
    elm.setAttribute('charset', 'EUC-JP');
    elm.setAttribute('type',    'text/javascript'); // 'text/X-arib-ecmascript; charset="euc-jp"'
    if (srcUri) elm.setAttribute('src', srcUri);
    return(elm);
  }
  function setKeyEventsAttributes(elm, ref) {
    var onClick   = ref.getAttribute('onClick');
    var onKeydown = ref.getAttribute('onKeydown');
    var onKeyup   = ref.getAttribute('onKeyup');

    if (onClick)   elm.onClick   = onClick;
    if (onKeydown) elm.onKeydown = onKeydown;
    if (onKeyup)   elm.onKeyup   = onKeyup;

    if (onClick || onKeydown || onKeyup)
      BML.Navigation.addFocusable(elm);
    
    return(elm);
  }
  function setFocusCtrlAttributes(elm, ref) {
    var aKey    = ref.getAttribute('accesskey');
    var onFocus = ref.getAttribute('onfocus');
    var onBlur  = ref.getAttribute('onblur');

    if (aKey)    BML.Navigation.addAccessKey(elm, aKey);
    if (onFocus) elm.onFocus = onFocus;
    if (onBlur)  elm.onBlur  = onBlur;
    
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function checkDocNode(node) {
    if (BML.Util.isOpera) return;
    if (String(node.xmlEncoding).toUpperCase() != 'EUC-JP')
      throw('invalid xml encoding:'+node.xmlEncoding);
    if (node.xmlVersion != '1.0')
      throw('invalid xml version:' +node.Version);
  }
  function checkDocTypeNode(node) {
    if (String(node.name).toLowerCase() != 'bml')
      throw('invalid doctype name:'     +node.name);

    BML.Util.each.call(DTD_DECLARATIONS, function(dtd) {
      if ((node.publicId == dtd[0]) && (node.systemId == dtd[1])) {
        BML.version = dtd[2];
        BML.Util.$break;
      }
    });
    if (!BML.version)
      throw('invalid doctype public id:"'+node.publicId +
            '" or system id:"' + node.systemId +'"');
  }
  function checkPINode(node) {
    if (String(node.target).toLowerCase() != 'bml')
      throw('invalid PI target:'+node.target);

    var versionMatcher = /bml-version=\"([\d\.]+)\"/;
    var match = versionMatcher.exec(node.nodeValue);
    if (!match || (match[1] != BML.version))
      throw('invalid PI node value:'+node.nodeValue);
  }
  function checkCommentNode(node) {}

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // structure module
  function processBodyElement(node, parent) {
    var elm = getFirstElementByTagName('body', parent);
    if (BML.Util.isOpera) {
      if (!elm) elm = document.appendChild(document.createElement('body'));
    } else {
      elm ? parent.removeChild(elm) : (elm = document.createElement('body'));
      bodyElement = { body : elm, parent : parent };
    }

    setCoreAttributes(elm, node);
    setI18nAttributes(elm, node);
    setStyleAttributes(elm, node);

    var func;
    func = node.getAttribute('onload');
    if (func) {
      func = stripEventHandlerString(func);
      eventHandlers['onload'] = (reservedNameFuncs[func] || func) + '();';
    }
    func = node.getAttribute('onunload');
    if (func) {
      func = stripEventHandlerString(func);
      eventHandlers['onunload'] = (reservedNameFuncs[func] || func) + '();';
      elm.setAttribute('onunload', "eval(BML.Builder.onunload();");
    }
    return(elm);
  }
  function processHeadElement(node, parent) {
    var elm  = getFirstElementByTagName('head', parent) ||
               parent.appendChild(document.createElement('head'));
    setI18nAttributes(elm, node);
    return(elm);
  }
  function processTitleElement(node, parent) {
    var elm = getFirstElementByTagName('title', parent) ||
              parent.appendChild(document.createElement('title'));
    setI18nAttributes(elm, node);
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // text module
  function processDivElement(node, parent) {
    var elm = parent.appendChild(document.createElement('div'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);
    return(elm);
  }
  function processBRElement(node, parent) {
    var elm = parent.appendChild(document.createElement('br'));
    setCoreAttributes(elm, node);
    setStyleAttributes (elm, node);
    return(elm);
  }
  function processParagraphElement(node, parent) {
    var elm = parent.appendChild(document.createElement('p'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);
    return(elm);
  }
  function processSpanElement(node, parent) {
    var elm = parent.appendChild(document.createElement('span'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // hypertext module
  function processAnchorElement(node, parent) {
    ///////////////////////////////////////////////////////////////////////////////////////////
    var elm = parent.appendChild(document.createElement('a'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);

    elm.setAttribute('charset', 'EUC-JP');
    var href = node.getAttribute('href');
    if (href) elm.setAttribute('href', href);
    
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // form module
  function processInputElement(node, parent) {
    ///////////////////////////////////////////////////////////////////////////////////////////
    var elm = parent.appendChild(document.createElement('input'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);

    var tmp;
//  tmp = node.getAttribute('defaultValue'); elm.setAttribute('defaultValue', tmp);
    tmp = node.getAttribute('disabled');     elm.setAttribute('disabled',     tmp);
    tmp = node.getAttribute('maxLength');    elm.setAttribute('maxLength',    tmp);
    tmp = node.getAttribute('readOnly');     elm.setAttribute('readOnly',     tmp);
    tmp = node.getAttribute('type');         elm.setAttribute('type',         tmp);
    tmp = node.getAttribute('value');        elm.setAttribute('value',        tmp);
    
    return(elm);
  }
  
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // object module
  function processObjectElement(node, parent) {
    var elm = parent.appendChild(document.createElement('object'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);

    var tmp;
    tmp = MIME_TYPE[node.getAttribute('type')]; if (tmp) elm.setAttribute('type', tmp);
    tmp = node.getAttribute('data');            if (tmp) elm.setAttribute('data', tmp);

    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // metainformation module
  function processMetaElement(node, parent) {
    return(parent);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // scripting module
  function processScriptElement(node, parent) {
    if (isFirstScript) {
      BML.Util.each.call(BML.config.prefixScriptIncPath, function(v) {
        scriptBuffer += getExternalScript(v);
      });
      isFirstScript = false;
    }

    var elm = null;
    var src = node.getAttribute('src');
    if (src) {
      scriptBuffer += getExternalScript(src);
    } else {
      if (isFirstInnerScript) {
        BML.Util.each.call(BML.config.suffixScriptIncPath, function(v) {
          scriptBuffer += getExternalScript(v);
        });
        isFirstInnerScript = false;
      }
      elm = setScriptAttributes(document.createElement('script'));
      parent.appendChild(elm);
    }

    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // style module
  function processStyleElement(node, parent) {
    var elm = parent.appendChild(document.createElement('style'));
    setI18nAttributes(elm, node);
    setDefaultAttributes(elm, {
      type  : 'text/css',
      media : 'all' // 'tv'
    });
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // link module
  function processLinkElement(node, parent) {
    var elm  = document.createElement('style');
    setI18nAttributes(elm, node);
    setDefaultAttributes(elm, {
      type  : 'text/css',
      media : 'all' // 'tv'
    });
    
    var href = BML.Util.combinePath(node.getAttribute('href'), BML.url);
    var ajax = new BML.Ajax(href, {
      overrideMimeType : 'text/css; charset=EUC-JP',
      asynchronous     : false,
      method           : 'GET'
    });
    elm.appendChild(document.createTextNode('/*'+href+'*'+"/\n"+
                                            processStyle(ajax.response.responseText)));
    parent.appendChild(elm);
    elm = parent;
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // bml module
  function processBmlElement(node, parent) {
    var elm = getFirstElementByTagName('html', parent) ||
              parent.appendChild(document.createElement('html'));
    setI18nAttributes(elm, node);
    setDefaultAttributes(elm, {
      xmlns : 'http://www.w3.org/1999/xhtml',
      lang  : 'ja'
    });
    return(elm);
  }
  function processBeventElement(node, parent) { return(parent); }
  function processBeitemElement(node, parent) {
    var prop = {};
    BML.Util.each.call([
      'id',      'time_mode',  'message_id',       'language_tag',
      'type',    'time_value', 'message_group_id', 'module_ref',
      'onoccur', 'object_id',  'message_version',  'subscribe',
      'es_ref'], function(v) {
        prop[v] = node.getAttribute(v);
    });
    BML.Bevent.entry(prop);
    return(parent);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function processTextNode(node, parent) {
    var elm = document.createTextNode(node.nodeValue);
    parent.appendChild(elm);
    return(elm);
  }
  function processCDATASection(node, parent) {
    var elm = (BML.Util.supportSpecificElement) ? 
      document.createCDATASection(node.nodeValue) :
      document.createTextNode    (node.nodeValue);
    parent.appendChild(elm);
    return(elm);
  }
  function processStyleCDATASection(node, parent) {
    var style = node.nodeValue;
    var elm = (BML.Util.supportSpecificElement) ? 
      document.createCDATASection(processStyle(style)) :
      document.createTextNode    (processStyle(style));
    parent.appendChild(elm);
    return(elm);
  }
  function processScriptCDATASection(node, parent) {
    scriptBuffer += node.nodeValue;
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function getInlineStyleProperties(parentNode, parentName) {
    if (!parentNode) return([0, 0]);

    var getStyle = BML.Util.getStyle;
    var fontSize = getStyle(parentNode, 'fontSize') || 0;
    var width    = 0;
    while(1) {
      if (parentName == 'p') {
        width = getStyle(parentNode, 'width') || 0;
        break;
      }
      parentNode = parentNode.parentNode;
      if (parentNode === null) break;
      parentName = parentNode.nodeName.toLowerCase();
    }

    var isUndefined = BML.Util.isUndefined;
    return([isUndefined(fontSize) ? 24  : parseInt(fontSize, 10),
            isUndefined(width)    ? 960 : parseInt(width,    10)]);
  }
  function getInlineCurrentXPosition(node, parent, parentName) {
    if (parentName == 'p') return(0);
    
    var sibling = null;
    if (!node || !node.parentNode) {
      sibling = parent.lastChild;
    } else {
      if (!node.isSameNode(parent.firstChild)) sibling = node.previousSibling;
    }

    if (!sibling) {
      while(1) {
        sibling = parent.previousSibling;
        if (sibling) break;
        parent = parent.parentNode;
        if (!parent || (parent.nodeName.toLowerCase() == 'p')) break;
      }
    }
    if (!sibling) return(0);
    
    var xpos = sibling._curXPos;
    return(isNaN(xpos ) ? 0 : xpos);
  }
  function handleInlineCtrlString(str, ref) {
    var prevNodeName  = ((ref.previousSibling || {}).nodeName || '').toLowerCase();
    var nextNodeName  = ((ref.nextSibling     || {}).nodeName || '').toLowerCase();

    var prev = (/^[\s\r\n]/.test(str) &&
                (prevNodeName == 'span') || (prevNodeName == 'a')) ? ' ' : '';
    var next = (/[\s\r\n]$/.test(str) &&
                (nextNodeName == 'span') || (nextNodeName == 'a') ||
                (nextNodeName == 'br')) ? ' ' : '';

    str = str.replace(/^\s+/,     '');
    str = str.replace(/\s+$/,     '');
    str = str.replace(/[\r\n]/mg, ' ');

    var buf = '';
    while(1) {
      if (!(/([^\s])\s+([^\s])/.test(str))) break;
      var l = RegExp.$1;
      var r = RegExp.$2;
      buf += RegExp.leftContext + l +
        (((l.charCodeAt(0) > 0xff) && (r.charCodeAt(0) > 0xff)) ? '' : ' ') + r;
      str  = RegExp.rightContext;
    }
    return(prev + buf + str + next);
  }
  function iterateWordBreak(str, node, ref, parent, parentName) {
    var tmp      = getInlineStyleProperties(parent, parentName);
    var fontSize = tmp[0];
    var width    = tmp[1];
    var pos      = getInlineCurrentXPosition(node, parent, parentName);

    // ɽ�����˹�碌��ʸ�����ǽưŪ���Ԥμ»�
    // character spacing��̤����(��style��������Ǥ���ФǤ�����)
    var buf = '', halfSize = Math.floor(fontSize / 2);
    for(var i = 0, l = str.length; i < l; i++) {
      var c = str.charAt(i);
      
      if (c == "\n") {
        buf += c;
        pos  = 0;
      } else {
        var cl = (str.charCodeAt(i) <= 0xff) ? halfSize : fontSize;
        pos   += cl;
        if (pos > width) {
          buf += "\n" + c;
          pos  = cl;
        } else {
          buf += c;
        }
      }
    }
    
    return([buf, pos]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////
  function processInlineString(str, node, ref, parent, parentName, isCDATA) {
    var text = str || '';
    text = isCDATA ? text.replace(/[\r\n?]/g, "\n") : handleInlineCtrlString(text, ref);

    var tmp = iterateWordBreak(text, node, ref, parent, parentName);
    var pos = tmp[1];
    text    = tmp[0];
      
      if (!ref.nextSibling) {
        var p = parent;
        while(1) {
          p._curXPos = pos;
          if (p.nextSibling) break;
          p = p.parentNode;
          if (!p || p.nodeName.toLowerCase() == 'p') break;
        }
      }

    node._curXPos  = pos;
    node._orgValue = str;
    node.nodeValue = text;
  }
  function processInlineTextNode(node, parent, parentName) {
    var elm = document.createTextNode('');
    elm._text_node = true;
    processInlineString(node.nodeValue, elm, node, parent, parentName, false);
    return(parent.appendChild(elm));
  }
  function processInlineCDATASection(node, parent, parentName) {
    var elm = (BML.Util.supportSpecificElement) ? 
      document.createCDATASection('') : document.createTextNode('');
    elm._cdata_section = true;
    processInlineString(node.nodeValue, elm, node, parent, parentName, true);
    return(parent.appendChild(elm));
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var TextLayoutElements = BML.Util.isSafari ?
    [ 'dataInterface', ['Text'],                  ['HTMLElement']                                                  ] :
    [ 'data',          ['Text', 'CDATASection' ], ['HTMLSpanElement', 'HTMLParagraphElement', 'HTMLAnchorElement'] ];

  var interfaceName = TextLayoutElements.shift();
  BML.Util.each.call(TextLayoutElements[0], function(elm) {
    try {
      eval(elm).prototype.__defineGetter__(interfaceName, function() { return(this.data); });
      eval(elm).prototype.__defineSetter__(interfaceName, function(str) {
        var parent     = this.parentNode;
        var parentName = parent.nodeName.toLowerCase();
        
        processInlineString(str, this, this, parent, parentName, this._cdata_section);
        
        // ����(pivot)�ʹߤ�����Node��Ƥ��̤�ʤ����Layout
        var pivot = this;
        while(1) {
          var nextSibling = pivot.nextSibling;
          while(1) {
            if (!nextSibling) break;
            nextSibling.layout(parent, parentName);
            nextSibling = nextSibling.nextSibling;
          }
          if (parentName == 'p') break;
          
          pivot  = parent;
          parent = pivot.parentNode;
          if (!parent) break;
          parentName = parent.nodeName.toLowerCase();
        }
      });
      eval(elm).prototype.layout = function(parent, parentName) {
        processInlineString(this._orgValue || '', this, this,
                            parent, parentName,
                            (this._cdata_section ? true : false));
      };
    } catch(e) {
      BML.Debug.error(e);
    }
  });
  BML.Util.each.call(TextLayoutElements[1], function(elm) {
    try {
      eval(elm).prototype.layout = function(parent, parentName) {
        var name       = this.nodeName.toLowerCase();
        var childNodes = this.childNodes;
        for(var i = 0, l = childNodes.length; i < l; i++) {
          childNodes[i].layout(this, name);
        }
      };
    } catch(e) {
      BML.Debug.error(e);
    }
  });

  if (BML.Util.isSafari) {
    HTMLObjectElement.prototype.__defineGetter__('dataInterface', function()    { return(this.data); });
    HTMLObjectElement.prototype.__defineSetter__('dataInterface', function(str) { this.data = str;   });
//  } else if (!BML.Util.supportSpecificElement) {
  } else {
    HTMLBRElement.prototype.layout = function() {};
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function rebuild(node, parent) {
    if (!node) return;

    document.currentFocus = null;
    document.currentEvent = null;
    
    var nType = node.nodeType, nName, parentName;
    if      (nType == NODETYPE.DOCUMENT_NODE)         { checkDocNode    (node); }
    else if (nType == NODETYPE.DOCUMENT_TYPE_NODE)    { checkDocTypeNode(node); }
    else if (nType == NODETYPE.PROC_INSTRUCTION_NODE) { checkPINode     (node); }
    else if (nType == NODETYPE.COMMENT_NODE)          { checkCommentNode(node); }
    else if (nType == NODETYPE.ELEMENT_NODE)          {
      nName = String(node.nodeName).toLowerCase();
      if      (nName == 'body')   { parent = processBodyElement     (node, parent); }
      else if (nName == 'head')   { parent = processHeadElement     (node, parent); }
      else if (nName == 'title')  { parent = processTitleElement    (node, parent); }
      else if (nName == 'div')    { parent = processDivElement      (node, parent); }
      else if (nName == 'br')     { parent = processBRElement       (node, parent); }
      else if (nName == 'p')      { parent = processParagraphElement(node, parent); }
      else if (nName == 'span')   { parent = processSpanElement     (node, parent); }
      else if (nName == 'a')      { parent = processAnchorElement   (node, parent); }
      else if (nName == 'input')  { parent = processInputElement    (node, parent); }
      else if (nName == 'object') { parent = processObjectElement   (node, parent); }
      else if (nName == 'meta')   { parent = processMetaElement     (node, parent); }
      else if (nName == 'script') { parent = processScriptElement   (node, parent); }
      else if (nName == 'style')  { parent = processStyleElement    (node, parent); }
      else if (nName == 'link')   { parent = processLinkElement     (node, parent); }
      else if (nName == 'bml')    { parent = processBmlElement      (node, parent); }
      else if (nName == 'bevent') { parent = processBeventElement   (node, parent); }
      else if (nName == 'beitem') { parent = processBeitemElement   (node, parent); }
      else    { throw("not handled yet :["+node.nodeName+"]("+node.tagName+")"); }
    }
    else if (nType == NODETYPE.TEXT_NODE)             {
      parentName = String(parent.nodeName).toLowerCase();
      if      (parentName == 'body')  { parent; }
      else if (parentName == 'head')  { parent; }
      else if (parentName == 'title') { parent = processTextNode(node, parent); }
      else if (parentName == 'div')   { parent; }
      else if (parentName == 'p')     { parent = processInlineTextNode(node, parent, parentName); }
      else if (parentName == 'span')  { parent = processInlineTextNode(node, parent, parentName); }
      else if (parentName == 'a')     { parent = processInlineTextNode(node, parent, parentName); }
      else if (parentName == 'html')  { parent; }
      else { throw('not handled yet :['+node.nodeName+']('+node.tagName+
                   ')['+node.nodeValue+']:parentNode:'+parentName); }

    }
    else if (nType == NODETYPE.CDATA_SECTION_NODE)    { 
      parentName = String(parent.nodeName).toLowerCase();
      if      (parentName == 'title')  { parent = processCDATASection      (node, parent); }
      else if (parentName == 'p')      { parent = processInlineCDATASection(node, parent, parentName); }
      else if (parentName == 'span')   { parent = processInlineCDATASection(node, parent, parentName); }
      else if (parentName == 'a')      { parent = processInlineCDATASection(node, parent, parentName); }
      else if (parentName == 'script') { parent = processScriptCDATASection(node, parent); }
      else if (parentName == 'style')  { parent = processStyleCDATASection (node, parent); }
      else  { throw('not handled yet :['+node.nodeName+']('+node.tagName+')<-['+parentName+']'); }
    }
    else { throw('not handled yet :['+node.nodeName+']('+node.tagName+')'); }
    
    var children = node.childNodes;
    for(var i = 0, l = children.length; i < l; i++) {
      rebuild(children[i], parent);
    }
  }
  
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  return({
    build : function(url) {
      var ajax = new BML.Ajax(url, {
        overrideMimeType : 'text/xml; charset=EUC-JP',
        asynchronous     : true,
        method           : 'GET',
        onSuccess : function(response) {
          BML.url = url;

          BML.Debug.info('[BML.Builder.build start]');
          var buildSTime = (new Date).getTime();

          rebuild(response.responseXML, document, document);

          var body;
          if (bodyElement) { // body���Ǥ�����кǸ��append����
            bodyElement['parent'].appendChild(bodyElement['body']);
            body = bodyElement['body'];
          } else {
            body = getFirstElementByTagName('body', document);
          }
            
          BML.Debug.info('[BML.Builder.build done :'+
                         ((new Date).getTime() - buildSTime)+'[ms]]');

          var head, elm;
          if (scriptBuffer) {
            // bml�˵���/���Ȥ����script���Ǥ�Ǹ�ˤޤȤ��append
            elm = setScriptAttributes(document.createElement('script'));
            elm.appendChild(document.createTextNode(scriptBuffer));
            head = getFirstElementByTagName('head', document);
            head.appendChild(elm);
          }

          // �ʥӥ��������ν����
          BML.Navigation.initialize();

          // body�κǸ��append����onload��¹Ԥ���
          elm = setScriptAttributes(document.createElement('script'));
          elm.appendChild(document.createTextNode("BML.Builder.onload();"));
          body.appendChild(elm);
        },
        onFailure : function(response) {
          BML.Debug.error('[BML.Builder.build : load failed('+url+'): '+
                          response.statusCode + ':'+response.statusText+']');
        }
      });
    },
    onload : function() {
      // body��onload���Ǥ������eval����
      if (eventHandlers['onload']) {
        try      { eval(eventHandlers['onload']); }
        catch(e) { BML.Debug.error(e); }
      }
      BML.Debug.info('[BML onload done: '+
                     ((new Date).getTime() - BML.Debug.getLoadStartTime())+'[ms]]');
    },
    onunload : function() {
      // body��onunload���Ǥ������eval����
      if (eventHandlers['onunload']) {
        try      { eval(eventHandlers['onunload']); }
        catch(e) { BML.Debug.error(e); }
      }
    },
    eventHandlers : eventHandlers
  });
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// ��ư����(IE̤�б��Τ���IE�ξ��ϲ���Ԥ�ʤ�)
/*@cc_on @if(1) (@_jscript)
  document.write('IE��̤�б��Ǥ�');
@else @*/
window.addEventListener('load', function() {
  BML.Debug.initialize();

  var bmlUri = BML.Util.parseURI(location.href);
  bmlUri = decodeURIComponent(bmlUri.query);
  BML.Debug.info('[bml url]:'+bmlUri);
  if (!bmlUri) return;

  BML.Navigation.grabInput();
  BML.Builder.build(bmlUri);
}, false);
/*@end @*/
