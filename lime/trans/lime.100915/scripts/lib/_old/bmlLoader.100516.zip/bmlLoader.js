//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
var BML = (typeof(BML) == 'undefined') ? {} : BML;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// ���б���
//   ��grayscale-color-index�����Ϥ��٤�̵��
//     - grayscale-color-index�����ˤ��ɽ������ϹԤ�ʤ�
//     - normalStyle.grayscaleColorIndex ��getter��default�ͤ��֤�
//     - normalStyle.grayscaleColorIndex ��setter��̤����
//   ��activeStyle / focusStyle �Ϥ��٤�̵��
//     - (activeStyle||focusStyle)��getter�Ϥ��٤�default�ͤ��֤�
//     - (activeStyle||focusStyle)��setter�Ϥ��٤�̤����
// ������ࡧ
//   ���桼�������Object����data�ץ��ѥƥ����Ѥ��ʤ�����
//     - ECMAScript���������.data��.dataInterface�˽񤭴������뤿��
// ��­��
//   ��safari(webkit)��ưŪ�ʳ���(src)���Ȥ���script���Ǥ�ưŪ��������ư��ʤ�
//     (script���Ǥ���������뤬ɾ������ʤ�)���ᡤ�����ե�������������script����
//     ��ľ��script�򵭽Ҥ���
// ��뤳�ȡ�
//   ������ɽ���θ����󻲾Ȥι�θ(��Matcher)
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function(dst, src) { for(var key in src) { dst[key] = src[key]; } })(BML, {
  startTime   : (function() { var d = new Date(); return(d.getSeconds() * 1000 + d.getMilliseconds()); })(),
  url         : '',
  config      : {
    cssIncludePath      : ['bml.css'],
    prefixScriptIncPath : ['../scripts/prefix.js'],
    suffixScriptIncPath : ['../scripts/suffix.js'],
    defaultFontName     :  'IPA�����å�',
    usableFontName      : {'IPA�����å�' : 1 }
  },
  bmlStyle    : {
    resolution          : '960x540',
    displayAspectRatio  : '16v9',
    usedKeyList         : 'basic data-button'
  }
});
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() {
  ///////////////////////////////////////////////////////////////////////////////////////////
  // ̤������BML��ϢClass��
  BML.UsedKeyList = {
    set         : function(list) {},
    isValidCode : function(node) {}
  };
  BML.Bevent = {
    entry : function(property) {},
    clear : function() {}
  };
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // Utility�ؿ���
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var slice       = Array.prototype.slice;
  var isIE        = !!(window.attachEvent && (navigator.userAgent.indexOf('opera') === -1));
  var isOpera     = Object.prototype.toString.call(window.opera) == '[object Opera]';
  var isSafari    = navigator.userAgent.indexOf('AppleWebKit/') > -1;
  var $break      = {};
  var uriMatcher  = /^(?:(https?:\/\/[^\/]+\/)((?:[^\/]*\/)*))((?:([^\?\#]*)\.([^\.\?\#]*))|([^\?\#\.]*))?(?:\?([^\#]*))?(?:#(.*))?/;
  function emptyFunction()   { }
  function getClass(obj)     { return(Object.prototype.toString.call(obj).match(/^\[object\s(.*)\]$/)[1]); }
  function isArray(obj)      { return(getClass(obj) == 'Array'); }
  function isUndefined(obj)  { return(typeof(obj) == 'undefined'); }
  function extend(dst, src)  { for(k in src) { dst[k] = src[k]; } return(dst); }
  function append(array) {
    var thisLength = this.length, length = array.length;
    while(length--) this[thisLength + length] = array[length];
    return(this);
  }
  function bind(context) {
    if ((arguments.length < 2) && isUndefined(arguments[0])) return(this);
    
    var __method = this, args = slice.call(arguments, 1);
    return(function() {
      var a = append.call(slice.call(args, 0), arguments);
      return(__method.apply(context, a));
    });
  }
  function wait(timeout, context) {
    var __method = this, args = slice.call(arguments, 2);
    return(window.setTimeout(function() {
      return(__method.apply(context, args));
    }, timeout * 1000));
  }
  function each(iterator, context) {
   context = context || this;
    try {
      for(var i = 0, l = this.length; i < l; i++) {
        iterator.call(context, this[i], i);
      }
    } catch(e) {
      if (e != $break) throw(e);
    }
    return(this);
  }
  function hashEach(iterator, context) {
    context = context || this;
    try {
      for(var key in this) {
        iterator.call(context, key, this[key]);
      }
    } catch(e) {
      if (e != $break) throw(e);
    }
    return(this);
  }
  function parseURI(uri) {
    if (!uri) return(null);

    var org = uri;
    uri = uri.replace(/\\/g, '/');
    var match = uriMatcher.exec(uri);
    
    return(match ? {
      host     : match[1] || '',
      path     : match[2] || '',
      file     : match[3] || '',
      name     : match[4] || match[6] || '',
      ext      : match[5] || '',
      query    : match[7] || '',
      fragment : match[8] || ''} : null);
  }
  function combinePath(src, current) {
    if (src.indexOf('http') >= 0) return(src);
    var p = parseURI(current);
    return(p.host+p.path+src);
  }
  function formatNumber(n) { return(((n.length < 2) ? '0' : '')+n); }
  function toColorCode(r, g, b) {
    r = Number(r).toString(16);
    g = Number(g).toString(16);
    b = Number(b).toString(16);
    return(formatNumber(r)+formatNumber(g)+formatNumber(b));
  }
  function camelize(str) {
    var parts = str.split('-');
    if (parts.length <= 1) return(str);

    var buf = String(parts[0]).toLowerCase();
    for(var i = 1, l = parts.length; i < l; i++) {
      var part = String(parts[i]);
      if (!part) continue;
      part = part.toLowerCase();
      buf += part.charAt(0).toUpperCase() + part.substring(1);
    }
    return(buf);
  }
  function hashToString(obj) {
    var s = '';
    for(var k in obj) { s += '['+k+':'+obj[k]+'] '; }
    return(s);
  }

  BML.Util = {
    isIE          : isIE,
    isOpera       : isOpera,
    isSafari      : isSafari,
    emptyFunction : emptyFunction,
    isArray       : isArray,
    isUndefined   : isUndefined,
    extend        : extend,
    bind          : bind,
    wait          : wait,
    each          : each,
    hashEach      : hashEach,
    parseURI      : parseURI,
    combinePath   : combinePath,
    toColorCode   : toColorCode,
    camelize      : camelize,
    hashToString  : hashToString
  };
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // Ajax��Ϣ
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var util = BML.Util;
  function toQueryPair(k, v) { return(util.isUndefined(v)? k : k+'='+encodeURIComponent(v===null? '' : v)); }
  function getTransport() {
    var transport = ['XMLHttpRequest()',
                     "ActiveXObject('Msxml2.XMLHTTP')",
                     "ActiveXObject('Microsoft.XMLHTTP')"];
    for(var i = 0, l = transport.length; i < l; i++) {
      try      { return(eval('new ' + transport[i])); }
      catch(e) { }
    }
    return(null);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var ajax = function(url, options) {
    this._complete = false;
    
    this.options = util.extend({
      method       : 'POST',
      asynchronous : true,
      contentType  : 'application/x-www-form-urlencoded',
      encoding     : 'UTF-8',
      parameters   : '',
      postBody     : ''
    }, options || {});
    this.method    = this.options.method.toUpperCase() || 'POST';
    this.transport = getTransport();

    if (url) this.request(url);
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.request = function(url) {
    if (!url) return;

    this.url       = url;
    this.accessUrl = url;
    this.query     = '';
    this.body      = null;

    var p = [], params = this.options.parameters || {}, val;
    for(var key in params) {
      val = params[key];
      key = encodeURIComponent(key);
      if (isArray(val)) {
        util.each.call(val, function(v) { p.push(toQueryPair(key, v)); });
      } else {
        p.push(toQueryPair(key, val));
      }
    }
    this.query = p.join('&');

    if (this.method == 'GET') {
      this.accessUrl += ((url.indexOf('?') > 0) ? '&' : '?') + this.query;
    } else {
      if (/Konqueror|Safari|KHTML/.test(navigator.userAgent)) this.query += '&_=';
      this.body = this.options.postBody || this.query;
    }

    try {
      var transport = this.transport;
      if (this.options.overrideMimeType && transport.overrideMimeType)
        transport.overrideMimeType(this.options.overrideMimeType);
      transport.open(this.method, this.accessUrl, this.options.asynchronous);
      if (this.options.asynchronous) util.wait.call(this.respondToReadyState, 0.01, this, 1);

      transport.onreadystatechange = util.bind.call(this.onStateChange, this);
      var headers = this.getRequestHeaders();
      for(key in headers) transport.setRequestHeader(key, headers[key]);

      transport.send(this.body);
      if (!this.options.asynchronous && transport.overrideMimeType) this.onStateChange();
      
    } catch(e) {
      this.dispatchException(e);
    }
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.onStateChange = function() {
    var readyState = this.transport.readyState;
    if ((readyState > 1) && ((readyState != 4) || !this._complete))
      this.respondToReadyState(readyState);
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.respondToReadyState = function(readyState) {
    var state    = ajax.Events[readyState];
    var response = new ajax.Response(this);

    try {
      (this.options['on' + state] || util.emptyFunction)(response);
    } catch(e) {
      this.dispatchException(e);
    }

    if (state == 'Complete') {
      try {
        this._complete = true;
        (this.options['on' + response.statusCode] ||
         this.options['on' + (this.success() ? 'Success' : 'Failure')] ||
         util.emptyFunction)(response);
      } catch(e) {
        this.dispatchException(e);
      }

      this.transport.onreadystatechange = util.emptyFunction;
    }
    this.response = response;
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.success = function() {
    var status = this.getHttpStatusCode();
    return(!status || ((status >= 200) && (status < 300)));
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.getRequestHeaders = function() {
    var headers = {
      'X-Requested-With' : 'XMLHttpRequest',
      'Accept'           : "text/javascript, text/html, application/xml, text/xml, */*"
    };
    if (this.method == 'POST') {
      headers['Content-type'] = this.options.contentType +
        (this.options.encoding ? '; charset=' + this.options.encoding : '');
      // Force "Connection: close" for older Mozilla browsers to work. see Mozilla Bugzilla #246651.
      if (this.transport.overrideMimeType &&
          (navigator.userAgent.match(/Gecko\/(\d{4})/) || [0,2005])[1] < 2005)
            headers['Connection'] = 'close';
    }

    return(headers);
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.prototype.getHttpStatusCode = function()     { try { return(this.transport.status || 0); } catch(e) { return(0); } };
  ajax.prototype.getHeader         = function(name) { try { return(this.transport.getResponseHeader(name) || null); } catch(e) { return(null); } };
  ajax.prototype.getAllHeaders     = function()     { try { return(this.transport.getAllResponseHeaders() || null); } catch(e) { return(null); } };
  ajax.prototype.dispatchException = function(e)    { (this.options.onError || util.emptyFunction)(this, e); };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var response = function(request) {
    this.status     = 0;
    this.statusText = '';
    this.request    = request;
    var transport   = this.transport  = request.transport;
    var readyState  = this.readyState = transport.readyState;

    if (((readyState > 2) && !util.isIE) || (readyState == 4)) {
      this.statusCode   = this._getHttpStatusCode();
      this.statusText   = this._getStatusText();
      this.responseText = (transport.responseText === null) ? '' : transport.responseText;
    }

    if (readyState == 4) {
      var xml = transport.responseXML;
      this.responseXML = util.isUndefined(xml) ? null : xml;
    }
  };
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  response.prototype._getHttpStatusCode     = ajax.prototype.getHttpStatusCode;
  response.prototype._getResponseHeader     = ajax.prototype.getHeader;
  response.prototype._getAllResponseHeaders = ajax.prototype.getAllHeaders;
  response.prototype._getStatusText         = function() { try { return(this.transport.statusText || ''); } catch(e) { return(''); } };

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ajax.Events = ['Uninitialized', 'Loading', 'Loaded', 'Interactive', 'Complete'];
  ajax.Response = response;
  
  BML.Ajax = ajax;
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // CLUT��Ϣ
  var palette = [
    // ARIB TR-B14 �軰�ԡ���2�� ��Ͽ1 ���������̸��꿧�׻���
    [  0,  0,  0,255,'000000'], [255,  0,  0,255,'ff0000'], [  0,255,  0,255,'00ff00'], [255,255,  0,255,'ffff00'],
    [  0,  0,255,255,'0000ff'], [255,  0,255,255,'ff00ff'], [  0,255,255,255,'00ffff'], [255,255,255,255,'ffffff'],
    [  0,  0,  0,  0,'000000'],
    [170,  0,  0,255,'aa0000'], [  0,170,  0,255,'00aa00'], [170,170,  0,255,'aaaa00'], [  0,  0,170,255,'0000aa'],
    [170,  0,170,255,'aa00aa'], [  0,170,170,255,'00aaaa'], [170,170,170,255,'aaaaaa'], [  0,  0, 85,255,'000055'],
    [  0, 85,  0,255,'005500'], [  0, 85, 85,255,'005555'], [  0, 85,170,255,'0055aa'], [  0, 85,255,255,'0055ff'],
    [  0,170, 85,255,'00aa55'], [  0,170,255,255,'00aaff'], [  0,255, 85,255,'00ff55'], [  0,255,170,255,'00ffaa'],
    [ 85,  0,  0,255,'550000'], [ 85,  0, 85,255,'550055'], [ 85,  0,170,255,'5500aa'], [ 85,  0,255,255,'5500ff'],
    [ 85, 85,  0,255,'555500'], [ 85, 85, 85,255,'555555'], [ 85, 85,170,255,'5555aa'], [ 85, 85,255,255,'5555ff'],
    [ 85,170,  0,255,'55aa00'], [ 85,170, 85,255,'55aa55'], [ 85,170,170,255,'55aaaa'], [ 85,170,255,255,'55aaff'],
    [ 85,255,  0,255,'55ff00'], [ 85,255, 85,255,'55ff55'], [ 85,255,170,255,'55ffaa'], [ 85,255,255,255,'55ffff'],
    [170,  0, 85,255,'aa0055'], [170,  0,255,255,'aa00ff'], [170, 85,  0,255,'aa5500'], [170, 85, 85,255,'aa5555'],
    [170, 85,170,255,'aa55aa'], [170, 85,255,255,'aa55ff'], [170,170, 85,255,'aaaa55'], [170,170,255,255,'aaaaff'],
    [170,255,  0,255,'aaff00'], [170,255, 85,255,'aaff55'], [170,255,170,255,'aaffaa'], [170,255,255,255,'aaffff'],
    [255,  0, 85,255,'ff0055'], [255,  0,170,255,'ff00aa'], [255, 85,  0,255,'ff5500'], [255, 85, 85,255,'ff5555'],
    [255, 85,170,255,'ff55aa'], [255, 85,255,255,'ff55ff'], [255,170,  0,255,'ffaa00'], [255,170, 85,255,'ffaa55'],
    [255,170,170,255,'ffaaaa'], [255,170,255,255,'ffaaff'], [255,255, 85,255,'ffff55'], [255,255,170,255,'ffffaa'],
    [  0,  0,  0,128,'000000'], [255,  0,  0,128,'ff0000'], [  0,255,  0,128,'00ff00'], [255,255,  0,128,'ffff00'],
    [  0,  0,255,128,'0000ff'], [255,  0,255,128,'ff00ff'], [  0,255,255,128,'00ffff'], [255,255,255,128,'ffffff'],
    [170,  0,  0,128,'aa0000'], [  0,170,  0,128,'00aa00'], [170,170,  0,128,'aaaa00'], [  0,  0,170,128,'0000aa'],
    [170,  0,170,128,'aa00aa'], [  0,170,170,128,'00aaaa'], [170,170,170,128,'aaaaaa'], [  0,  0, 85,128,'000055'],
    [  0, 85,  0,128,'005500'], [  0, 85, 85,128,'005555'], [  0, 85,170,128,'0055aa'], [  0, 85,255,128,'0055ff'],
    [  0,170, 85,128,'00aa55'], [  0,170,255,128,'00aaff'], [  0,255, 85,128,'00ff55'], [  0,255,170,128,'00ffaa'],
    [ 85,  0,  0,128,'550000'], [ 85,  0, 85,128,'550055'], [ 85,  0,170,128,'5500aa'], [ 85,  0,255,128,'5500ff'],
    [ 85, 85,  0,128,'555500'], [ 85, 85, 85,128,'555555'], [ 85, 85,170,128,'5555aa'], [ 85, 85,255,128,'5555ff'],
    [ 85,170,  0,128,'55aa00'], [ 85,170, 85,128,'55aa55'], [ 85,170,170,128,'55aaaa'], [ 85,170,255,128,'55aaff'],
    [ 85,255,  0,128,'55ff00'], [ 85,255, 85,128,'55ff55'], [ 85,255,170,128,'55ffaa'], [ 85,255,255,128,'55ffff'],
    [170,  0, 85,128,'aa0055'], [170,  0,255,128,'aa00ff'], [170, 85,  0,128,'aa5500'], [170, 85, 85,128,'aa5555'],
    [170, 85,170,128,'aa55aa'], [170, 85,255,128,'aa55ff'], [170,170, 85,128,'aaaa55'], [170,170,255,128,'aaaaff'],
    [170,255,  0,128,'aaff00'], [170,255, 85,128,'aaff55'], [170,255,170,128,'aaffaa'], [170,255,255,128,'aaffff'],
    [255,  0, 85,128,'ff0055'], [255,  0,170,128,'ff00aa'], [255, 85,  0,128,'ff5500'], [255, 85, 85,128,'ff5555'],
    [255, 85,170,128,'ff55aa'], [255, 85,255,128,'ff55ff'], [255,170,  0,128,'ffaa00'], [255,170, 85,128,'ffaa55'],
    [255,170,170,128,'ffaaaa'], [255,170,255,128,'ffaaff'], [255,255, 85,128,'ffff55']
  ];
  var codeToIdx = {};
  BML.Util.each.call(palette, function(entry, idx) {
    if (!codeToIdx[entry[4]]) codeToIdx[entry[4]] = idx;
  });
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  BML.Clut = {
    load : function(url) {
      var ajax = new BML.Ajax(url, {
        overrideMimeType : 'text/plain; charset=x-user-defined',
        asynchronous     : false,
        method           : 'GET'
      });
      var bytes = [];
      var stream = ajax.response.responseText;
      for(var i = 0, l = stream.length; i < l; i++) {
        bytes[i] = stream.charCodeAt(i) & 0x00ff;
      }
      
      var flags  = bytes.shift();
      var sIdx   = bytes.shift();
      var eIdx   = bytes.shift();
      var toCode = BML.Util.toColorCode;
      while(sIdx <= eIdx) {
        var y  = bytes.shift();
        var cb = bytes.shift();
        var cr = bytes.shift();
        var r  = Math.floor(1.164 * (y-16)                    + 1.596 * (cr-128));
        var g  = Math.floor(1.164 * (y-16) - 0.391 * (cb-128) - 0.813 * (cr-128));
        var b  = Math.floor(1.164 * (y-16) + 2.018 * (cb-128));
        r = Math.max(0, Math.min(255, r));
        g = Math.max(0, Math.min(255, g));
        b = Math.max(0, Math.min(255, b));

        var code        = toCode(r,g,b);
        palette[sIdx]   = [r, g, b, bytes.shift(), code];
        codeToIdx[code] = sIdx++;
      }
    },
    getColorCode : function(idx) {
      return(((idx < 0) || (idx >= palette.length) || !palette[idx]) ?
             '000000' : palette[idx][4]);
    },
    getRGB : function(idx) {
      return(((idx < 0) || (idx >= palette.length)) ?
             { r : 0, g : 0, b : 0, a : 0 } :
             (function() {
             var p = palette[idx];
             return({ r : p[0], g : p[1], b : p[2], a : p[3] });
           })());
    },
    codeToIdx : function(code) {
      var idx = codeToIdx[code.toLowerCode()];
      return((idx >= 0)? idx : -1);
    }
  };
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // Navigation��Ϣ
  ///////////////////////////////////////////////////////////////////////////////////////////
 var keycode = {
    // see: ARIB-B24 Appendix.2 5.1.8
     38 :  1, 40 :  2, 37 :  3, 39 :  4,  // up(��),down(��),left(��),right(��)
     48 :  5, 49 :  6, 50 :  7, 51 :  8,  //  0(0), 1(1), 2(2), 3(3),
     52 :  9, 53 : 10, 54 : 11, 55 : 12,  //  4(4), 5(5), 6(6), 7(7),
     56 : 13, 57 : 14,109 : 15,222 : 16,  //  8(8), 9(9),10(-),11(^),
    220 : 17,                             // 12(\)
     13 : 18, 88 : 18,  8 : 19, 68 : 20,  // Enter(Return/x),Back(BS),d-Button(d)
     66 : 21, 82 : 22, 71 : 23, 89 : 24   // B(b),R(r),G(g),Y(y)
  };
  var navIdxToElement    = [];
  var accessKeyToElement = {};
  var focusableElement   = [];
  BML.Navigation = {
    addNavIndex  : function(elm, idx) { navIdxToElement[idx]    = elm; },
    addAccessKey : function(elm, key) { accessKeyToElement[key] = elm; },
    addFocusable : function(elm)      { focusableElement.push(elm);    },
    focus        : function(elm)      { console.debug(elm.nodeName+"("+elm.id+")");   },
    blur         : function(elm)      { console.debug(elm.nodeName+"("+elm.id+")");   }
  };
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // normalStyle/activeStyle/focusStyle/focus/blur��Ϣ
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function getStyle(node, style) {
    var value = node.style[style];
    if (!value || (value == 'auto')) {
      var css = node.currentStyle || document.defaultView.getComputedStyle(node, null);
      value = css ? css[style] : null;
    }
    return((value == 'auto')? null : value);
  }
  var supportSpecificElementExtensions = (function() {
    return(!BML.Util.isUndefined(window.HTMLSpanElement));
  })();
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var normalStyleTargets = supportSpecificElementExtensions ?
    [ 'HTMLDivElement',    'HTMLSpanElement',  'HTMLParagraphElement', 'HTMLBRElement',
      'HTMLAnchorElement', 'HTMLInputElement', 'HTMLObjectElement',    'HTMLBodyElement' ] :
    ['HTMLElement'];
  var cssPseudoClassStyleTargets = supportSpecificElementExtensions ?
    [ 'HTMLDivElement',    'HTMLSpanElement',  'HTMLParagraphElement',
      'HTMLAnchorElement', 'HTMLInputElement', 'HTMLObjectElement' ] :
    ['HTMLElement'];
  var focusBlurTargets = supportSpecificElementExtensions ?
    [ 'HTMLDivElement',    'HTMLSpanElement',  'HTMLParagraphElement', 
      'HTMLAnchorElement', 'HTMLInputElement', 'HTMLObjectElement' ] :
    ['HTMLElement'];
  
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // pseudo normalStyle Object
  function normalStyleObj(node) {
    this.node = node;
    if (!node._bmlStyle) node._bmlStyle = {};
  }
  BML.Util.each.call([// read only property
   'paddingTop',  'paddingBottom', 'paddingLeft', 'paddingRight',
   'borderWidth', 'borderStyle',
   'lineHeight',  'textAlign',     'letterSpacing'
  ], function(key) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      return(this.node.style[key]);
    });
  });

  BML.Util.each.call([ // readable/writable property
    'left',       'top',        'width',    'height',
    'visibility', 'fontFamily', 'fontSize', 'fontWeight'
  ], function(key) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      return(getStyle(this.node, key));
    });
    normalStyleObj.prototype.__defineSetter__(key, (function(k) {
      return(function(v) { this.node.style[k] = v; });
    })(key));
  });

  BML.Util.each.call([
    'clut',  'resolution', 'displayAspectRatio',
    'navUp', 'navDown',    'navLeft', 'navRight', 'navIndex'
  ], function(key) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      return((this.node.nodeName.toLowerCase() == 'body') ?
             BML.bmlStyle[key] : this.node._bmlStyle[key]);
    });
  });
  
  BML.Util.hashEach.call({
    usedKeyList : function(key) { return(function(val) {
      BML.bmlStyle[key] = val;
      BML.UsedKeyList.set(val);
    }); }
  }, function(key, val) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      return((this.node.nodeName.toLowerCase() == 'body') ?
             BML.bmlStyle[key] : this.node._bmlStyle[key]);
    });
    normalStyleObj.prototype.__defineSetter__(key, val(key));
  });

  BML.Util.each.call([
    'borderTopColorIndex',  'borderRightColorIndex',
    'borderLeftColorIndex', 'borderbottomColorIndex',
    'backgroundColorIndex', 'colorIndex'
  ], function(key) {
    normalStyleObj.prototype.__defineGetter__(key, function() {
      var color = getStyle(this.node, key.substring(0, key.length - 5));
      if (/rgb\((\d+)[^\d]+(\d+)[^\d]+(\d+)\)/.test(color)) {
        color = BML.Util.toColorCode(RegExp.$1, RegExp.$2, RegExp.$3);
      }
      return(BML.Clut.codeToIdx(color));
    });
    normalStyleObj.prototype.__defineSetter__(key, function(val) {
      this.node.style[key.substring(0, key.length - 5)] = val;
    });
  });
  normalStyleObj.prototype.__defineGetter__('grayscaleColorIndex', function() {
    return('30 15'); // return default value
  });
  normalStyleObj.prototype.__defineSetter__('grayscaleColorIndex', function(val) {
  });

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // pseudo fucusStyle / active Object
  var cssPseudoClassStyleObj = {
    left : 0, top  : 0, width : 0, height : 0, visibility : 'inherit',
    fontFamily : BML.config.defaultFontName, fontSize  : '24px', fontWeight : 'normal',
    colorIndex : 0, backgroundColorIndex : 0,
    borderTopColorIndex : 0, borderBottomColorIndex : 0,
    borderRightColorIndex : 0, borderLeftColorIndex : 0,
    grayscaleColorIndex : 0
  };

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  BML.Util.each.call(normalStyleTargets, function(elm) {
    try {
      eval(elm).prototype.__defineGetter__('normalStyle', function() {
        if (!this._normalStyleObj) this._normalStyleObj = new normalStyleObj(this);
        return(this._normalStyleObj);
      });
    } catch(e) {
      console.debug(e);
    }
  });
  BML.Util.each.call(cssPseudoClassStyleTargets, function(elm) {
    try {
      eval(elm).prototype.__defineGetter__('focusStyle',  function() {
        if (!this._focusStyleObj)  this._focusStyleObj  = BML.Util.extend({}, cssPseudoClassStyleObj);
        return(this._focusStyleObj);
      });
      eval(elm).prototype.__defineGetter__('activeStyle', function() {
        if (!this._activeStyleObj) this._activeStyleObj = BML.Util.extend({}, cssPseudoClassStyleObj);
        return(this._activeStyleObj);
      });
    } catch(e) {
      console.debug(e);
    }
    BML.Util.each.call(focusBlurTargets, function(elm) {
    try {
      eval(elm).prototype.focus = function() { BML.Navigation.focus(this); };
      eval(elm).prototype.blur  = function() { BML.Navigation.blur (this); };
    } catch(e) {
      console.debug(e);
    }
  });
  });
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
(function() { // bml�ѡ�����Ϣ
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  var NODETYPE = {
    UNKNOWN_NODE           :  0,
    ELEMENT_NODE           :  1,
    ATTRIBUTE_NODE         :  2,
    TEXT_NODE              :  3,
    CDATA_SECTION_NODE     :  4,
    ENTITY_REFERENCE_NODE  :  5,
    ENTITY_NODE            :  6,
    PROC_INSTRUCTION_NODE  :  7,
    COMMENT_NODE           :  8,
    DOCUMENT_NODE          :  9,
    DOCUMENT_TYPE_NODE     : 10,
    DOCUMENT_FRAGMENT_NODE : 11,
    NOTATION_NODE          : 12
  };
  var MIME_TYPE = {
    'image/jpeg'                            : 'image/jpeg',
    'image/X-arib-png'                      : 'image/png', 
    'image/X-arib-mng'                      : 'video/mng',
    'audio/X-arib-mpeg2-aac'                : null,
    'audio/X-arib-aiff'                     : 'audio/aiff',
    'application/X-arib-contentPlayControl' : null,
    'application/X-aribmpeg2-tts'           : null
  };
  var DOCTYPE_PUBLIC_ID   = '-//ARIB STD-B24:1999//DTD BML Document for IPTV//JA';
  var DOCTYPE_SYSTEM_ID   = 'http://www.arib.or.jp/B24/DTD/bml_x_x_iptv.dtd';
  var isFirstScript       = true;
  var isFirstInnerScript  = true;
  var isCssIncluded       = false;
  var clutMatcher         = /([^\w])clut[^\w:]*:[^\w]*(url\([^\w]*([^\)\s]+\s*)\))/m;
  var usedKeyListMatcher  = /([^\w])used-key-list[^\w:]*:\s*([^;\}\s]+)\s*;?/m;
  var resolutionMatcher   = /([^\w])resolution[^\w:]*:([^;\}]+);?/mg;
  var aspectRatioMatcher  = /([^\w])display-aspect-ratio[^\w:]*:\s*([^;\}\s]+)\s*;?/mg;
  var grayscaleMatcher    = /([^\w])grayscale-color-index[^\w:]*:[^;\}]+;?/mg;
  var colorIndexMatcher   = /color-index[^\w:]*:\s*(\d+)(\s+(\d+))?/m;
  var fontFamilyMatcher   = /([^\w])font-family[^\w:]*:\s*[^\s;\}]/m;
  var navAttributeMatcher = /(nav-\w+)[^:]*:[^\d]*(\d+)[^\w;\}]*;?/m;
  var reservedNameFuncs   = {};
  var rnOnloadMatcher     = /([^\w]function[^\w]+onload)([^\w])/m;
  var rnOnunloadMatcher   = /([^\w]function[^\w]+onunload)([^\w])/m;
  var eventHandlers       = {};
  var bodyElement         = null;

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function setCssStyle(node, style) {
    if (BML.Util.isIE) node.style.cssText = style;
    else               node.setAttribute('style', style);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function getFirstElementByTagName(name, node) {
    if (!node) return(null);
    var children = node.getElementsByTagName(name);
    return((children.length > 0) ? children[0] : null);
  }
  function fixScript(script) {
    if (!script) return('');

//    script = script.replace(/\.data([^\w])/g, "\.dataInterface$1");

    // avoid reserved words
    if (rnOnloadMatcher.test(script)) {
      script = RegExp.leftContext + RegExp.$1 + '_mod' + RegExp.$2 + RegExp.rightContext;
      reservedNameFuncs['onload']   = 'onload_mod';
    }
    if (rnOnunloadMatcher.test(script)) {
      script = RegExp.leftContext + RegExp.$1 + '_mod' + RegExp.$2 + RegExp.rightContext;
      reservedNameFuncs['onunload'] = 'onunload_mod';
    }

    return(script);
  }
  function stripEventHandlerString(str) { // 'hoge();'->'hoge'
    return(str.replace(/^\s*([^\s\(]+)\([^\)]*\)\s*;/, "$1"));
  }
  function colorIndexToColorCode(style) {
    var buf = '';
    while(1) {
      if (!colorIndexMatcher.test(style)) break;
      buf  += RegExp.leftContext + 'color:#' + BML.Clut.getColorCode(RegExp.$1);
      style = RegExp.rightContext;
    }
    return(buf + style);
  }
  function processStyle(style, elm) {
    style = style.replace(grayscaleMatcher,  "$1");

    if (!elm || (String(elm.nodeName).toLowerCase() == 'body')) {
      if (clutMatcher.test(style)) {
        style = RegExp.leftContext + RegExp.$1 + RegExp.rightContext;
        var p = RegExp.$2, f = RegExp.$3;
        BML.bmlStyle['clut'] = RegExp.$2;
        BML.Clut.load(RegExp.$3);
        console.debug('[CLUT:'+p+'] -> BML.Clut.load('+f+')');
      }
      if (usedKeyListMatcher.test(style)) {
        style = RegExp.leftContext + RegExp.$1 + RegExp.rightContext;
        var k = RegExp.$2;
        BML.bmlStyle['usedKeyList'] = RegExp.$2;
        BML.UsedKeyList.set(RegExp.$2);
        console.debug('[UsedKeyList:'+k+']');
      }
      if (aspectRatioMatcher.test(style)) {
        style = RegExp.leftContext + RegExp.$1 + RegExp.rightContext;
        var a = RegExp.$2;
        BML.bmlStyle['displayAspectRatio'] = RegExp.$2;
        console.debug('[DisplayAspectRatio:'+a+']');
      }
      style = style.replace(resolutionMatcher, "$1");
    }

    if (elm) {
      // get nav-xxx
      var buf = '', nav = {}, camelize = BML.Util.camelize;
      while(1) {
        if (!navAttributeMatcher.test(style)) break;
        nav[camelize(RegExp.$1)] = RegExp.$2;
        buf  += RegExp.leftContext;
        style = RegExp.rightContext;
      }
      style = buf + style;
      
      if (!elm._bmlStyle) elm._bmlStyle = {};
      BML.Util.extend(elm._bmlStyle, nav);
      if (nav['navIndex'] >= 0) BML.Navigation.addNavIndex(elm, nav['navIndex']);
    }
      
    fontFamilyMatcher   = /([^\w])font-family[^\w:]*:\s*([^\s;\}]+)\s*;?/m;
    if (fontFamilyMatcher.test(style) && !BML.config.usableFontName[RegExp.$2]) {
      style = RegExp.leftContext + RegExp.$1 + RegExp.rightContext;
    }
    style = colorIndexToColorCode(style);

    return(style);
  }
  function createExternalSrcScriptTag(src) {
    var elm = setScriptAttributes(document.createElement('script'));
    src = BML.Util.combinePath(src, BML.url);
    var ajax = new BML.Ajax(src, {
      overrideMimeType : 'application/javascript; charset=EUC-JP',
      asynchronous     : false,
      method           : 'GET'
    });
    elm.appendChild(document.createTextNode('//'+src+"\n"+
                                            fixScript(ajax.response.responseText)));
    return(elm);
  }

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function setDefaultAttributes(elm, prop) {
    for(var k in prop) { elm.setAttribute(k, prop[k]); }
    return(elm);
  }
  function setCoreAttributes(elm, ref) {
    var tmp;
    tmp = ref.getAttribute('id');    if (tmp) elm.setAttribute('id',    tmp);
    tmp = ref.getAttribute('class'); if (tmp) elm.setAttribute('class', tmp);
    return(elm);
  }
  function setI18nAttributes(elm, ref) {
    elm.setAttribute('xml:lang', 'ja');
    return(elm);
  }
  function setStyleAttributes(elm, ref) {
    var style = ref.getAttribute('style');
    if (!style) return(elm);

    setCssStyle(elm, processStyle(style, elm));
    return(elm);
  }
  function setScriptAttributes(elm, srcUri) {
    elm.setAttribute('charset', 'EUC-JP');
    elm.setAttribute('type',    'text/javascript'); // 'text/X-arib-ecmascript; charset="euc-jp"'
    if (srcUri) elm.setAttribute('src', srcUri);
    return(elm);
  }
  function setKeyEventsAttributes(elm, ref) {
    var onClick   = ref.getAttribute('onClick');
    var onKeydown = ref.getAttribute('onKeydown');
    var onKeyup   = ref.getAttribute('onKeyup');

    if (onClick)   elm.onClick   = onClick;
    if (onKeydown) elm.onKeydown = onKeydown;
    if (onKeyup)   elm.onKeyup   = onKeyup;

    if (onClick || onKeydown || onKeyup)
      BML.Navigation.addFocusable(elm);
    
    return(elm);
  }
  function setFocusCtrlAttributes(elm, ref) {
    var aKey    = ref.getAttribute('accesskey');
    var onFocus = ref.getAttribute('onfocus');
    var onBlur  = ref.getAttribute('onblur');

    if (aKey)    BML.Navigation.addAccessKey(elm, aKey);
    if (onFocus) elm.onFocus = onFocus;
    if (onBlur)  elm.onBlur  = onBlur;
    
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function checkDocNode(node) {
    if (BML.Util.isOpera) return;
    if (String(node.xmlEncoding).toUpperCase() != 'EUC-JP')
      throw('invalid xml encoding:'+node.xmlEncoding);
    if (node.xmlVersion != '1.0')
      throw('invalid xml version:' +node.Version);
  }
  function checkDocTypeNode(node) {
    if (String(node.name).toLowerCase() != 'bml')
      throw('invalid doctype name:'     +node.name);
    if (node.publicId != DOCTYPE_PUBLIC_ID)
      throw('invalid doctype public id:'+node.publicId);
    if (node.systemId != DOCTYPE_SYSTEM_ID)
      throw('invalid doctype system id:'+node.systemId);
  }
  function checkPINode(node) {
    if (String(node.target).toLowerCase() != 'bml')
      throw('invalid PI target:'+node.target);
    if (!(/bml-version=\"100\.0\"/i.test(node.nodeValue)))
      throw('invalid PI node value:'+node.nodeValue);
  }
  function checkCommentNode(node) {}
  function processTextNode(node, parent) {
    var elm = document.createTextNode(node.nodeValue);
    parent.appendChild(elm);
    return(elm);
  }

  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // structure module
  function processBodyElement(node, parent) {
    var elm = getFirstElementByTagName('body', parent);
    if (BML.Util.isOpera) {
      if (!elm) elm = document.appendChild(document.createElement('body'));
    } else {
      elm ? parent.removeChild(elm) : (elm = document.createElement('body'));
      bodyElement = { body : elm, parent : parent };
    }

    setCoreAttributes(elm, node);
    setI18nAttributes(elm, node);
    setStyleAttributes(elm, node);

    var func;
    func = node.getAttribute('onload');
    if (func) {
      func = stripEventHandlerString(func);
      eventHandlers['onload'] = (reservedNameFuncs[func] || func) + '();';
    }
    func = node.getAttribute('onunload');
    if (func) {
      func = stripEventHandlerString(func);
      eventHandlers['onunload'] = (reservedNameFuncs[func] || func) + '();';
      elm.setAttribute('onunload', "eval(BML.Builder.eventHandlers['onunload'])");
    }
    return(elm);
  }
  function processHeadElement(node, parent) {
    var elm  = getFirstElementByTagName('head', parent) ||
               parent.appendChild(document.createElement('head'));
    setI18nAttributes(elm, node);
    return(elm);
  }
  function processTitleElement(node, parent) {
    var elm = getFirstElementByTagName('title', parent) ||
              parent.appendChild(document.createElement('title'));
    setI18nAttributes(elm, node);
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // text module
  function processDivElement(node, parent) {
    var elm = parent.appendChild(document.createElement('div'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);
    return(elm);
  }
  function processBRElement(node, parent) {
    var elm = parent.appendChild(document.createElement('br'));
    setCoreAttributes(elm, node);
    setStyleAttributes (elm, node);
    return(elm);
  }
  function processParagraphElement(node, parent) {
    var elm = parent.appendChild(document.createElement('p'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);
    return(elm);
  }
  function processSpanElement(node, parent) {
    var elm = parent.appendChild(document.createElement('span'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // hypertext module
  function processAnchorElement(node, parent) {
    ///////////////////////////////////////////////////////////////////////////////////////////
    var elm = parent.appendChild(document.createElement('a'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);

    elm.setAttribute('charset', 'EUC-JP');
    var href = node.getAttribute('href');
    if (href) elm.setAttribute('href', href);
    
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // form module
  function processInputElement(node, parent) {
    ///////////////////////////////////////////////////////////////////////////////////////////
    var elm = parent.appendChild(document.createElement('input'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);

    var tmp;
//  tmp = node.getAttribute('defaultValue'); elm.setAttribute('defaultValue', tmp);
    tmp = node.getAttribute('disabled');     elm.setAttribute('disabled',     tmp);
    tmp = node.getAttribute('maxLength');    elm.setAttribute('maxLength',    tmp);
    tmp = node.getAttribute('readOnly');     elm.setAttribute('readOnly',     tmp);
    tmp = node.getAttribute('type');         elm.setAttribute('type',         tmp);
    tmp = node.getAttribute('value');        elm.setAttribute('value',        tmp);
    
    return(elm);
  }
  
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // object module
  function processObjectElement(node, parent) {
    var elm = parent.appendChild(document.createElement('object'));
    setCoreAttributes (elm, node);
    setI18nAttributes (elm, node);
    setStyleAttributes(elm, node);
    setKeyEventsAttributes(elm, node);
    setFocusCtrlAttributes(elm, node);

    var tmp;
    tmp = MIME_TYPE[node.getAttribute('type')]; if (tmp) elm.setAttribute('type', tmp);
    tmp = node.getAttribute('data');            if (tmp) elm.setAttribute('data', tmp);

    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // metainformation module
  function processMetaElement(node, parent) {
    return(parent);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // scripting module
  function processScriptElement(node, parent) {
    if (isFirstScript) {
      if (BML.Util.isSafari) {
        BML.Util.each.call(BML.config.prefixScriptIncPath, function(v) {
          parent.appendChild(createExternalSrcScriptTag(v));
        });
      } else {
        BML.Util.each.call(BML.config.prefixScriptIncPath, function(v) {
          parent.appendChild(setScriptAttributes(document.createElement('script'), v));
        });
      }
      isFirstScript = false;
    }
    var src = node.getAttribute('src');
    if (src) {
      var elm = createExternalSrcScriptTag(src);
      parent.appendChild(elm);
      elm = parent;

    } else if (isFirstInnerScript) {
      if (!BML.Util.isSafari) {
        BML.Util.each.call(BML.config.suffixScriptIncPath, function(v) {
          parent.appendChild(setScriptAttributes(document.createElement('script'), v));
        });
      }
      isFirstInnerScript = false;

      var elm = setScriptAttributes(document.createElement('script'));
      parent.appendChild(elm);
    }

    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // style module
  function processStyleElement(node, parent) {
    if (!isCssIncluded) {
      BML.Util.each.call(BML.config.cssIncludePath, function(v) {
        parent.appendChild(setDefaultAttributes(document.createElement('link'), {
          charset : 'EUC-JP',
          href    :  v,
          media   : 'all', // 'tv',
          rel     : 'stylesheet',
          type    : 'text/css'
          }));
      });
      isCssIncluded = true;
    }

    var elm = parent.appendChild(document.createElement('style'));
    setI18nAttributes(elm, node);
    setDefaultAttributes(elm, {
      type  : 'text/css',
      media : 'all' // 'tv'
    });
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // link module
  function processLinkElement(node, parent) {
    var elm  = document.createElement('style');
    setI18nAttributes(elm, node);
    setDefaultAttributes(elm, {
      type  : 'text/css',
      media : 'all' // 'tv'
    });
    
    var href = BML.Util.combinePath(node.getAttribute('href'), BML.url);
    var ajax = new BML.Ajax(href, {
      overrideMimeType : 'text/css; charset=EUC-JP',
      asynchronous     : false,
      method           : 'GET'
    });
    elm.appendChild(document.createTextNode('/*'+href+"*/\n"+
                                            processStyle(ajax.response.responseText)));
    parent.appendChild(elm);
    elm = parent;
    return(elm);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  // bml module
  function processBmlElement(node, parent) {
    var elm = getFirstElementByTagName('html', parent) ||
              parent.appendChild(document.createElement('html'));
    setI18nAttributes(elm, node);
    setDefaultAttributes(elm, {
      xmlns : 'http://www.w3.org/1999/xhtml',
      lang  : 'ja'
    });
    return(elm);
  }
  function processBeventElement(node, parent) { return(parent); }
  function processBeitemElement(node, parent) {
    var prop = {};
    BML.Util.each.call([
      'id',      'time_mode',  'message_id',       'language_tag',
      'type',    'time_value', 'message_group_id', 'module_ref',
      'onoccur', 'object_id',  'message_version',  'subscribe',
      'es_ref'], function(v) {
        prop[v] = node.getAttribute(v);
    });
    BML.Bevent.entry(prop);
    return(parent);
  }
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function processStyleCDATASection(node, parent) {
    var style = node.textContent;

    var elm = document.createTextNode(processStyle(style));
    parent.appendChild(elm);
    return(elm);
  }
  function processScriptCDATASection(node, parent) {
    return(parent.appendChild(document.createTextNode(fixScript(node.textContent))));
  }
  
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  function rebuild(node, parent) {
    if (!node) return;

    document.currentFocus = null;
    document.currentEvent = null;
    
    var nType = node.nodeType;
    if      (nType == NODETYPE.DOCUMENT_NODE)         { checkDocNode    (node); }
    else if (nType == NODETYPE.DOCUMENT_TYPE_NODE)    { checkDocTypeNode(node); }
    else if (nType == NODETYPE.PROC_INSTRUCTION_NODE) { checkPINode     (node); }
    else if (nType == NODETYPE.COMMENT_NODE)          { checkCommentNode(node); }
    else if (nType == NODETYPE.ELEMENT_NODE)          {
      var nName = String(node.nodeName).toLowerCase();
      if      (nName == 'body')   { parent = processBodyElement     (node, parent); }
      else if (nName == 'head')   { parent = processHeadElement     (node, parent); }
      else if (nName == 'title')  { parent = processTitleElement    (node, parent); }
      else if (nName == 'div')    { parent = processDivElement      (node, parent); }
      else if (nName == 'br')     { parent = processBRElement       (node, parent); }
      else if (nName == 'p')      { parent = processParagraphElement(node, parent); }
      else if (nName == 'span')   { parent = processSpanElement     (node, parent); }
      else if (nName == 'a')      { parent = processAnchorElement   (node, parent); }
      else if (nName == 'input')  { parent = processInputElement    (node, parent); }
      else if (nName == 'object') { parent = processObjectElement   (node, parent); }
      else if (nName == 'meta')   { parent = processMetaElement     (node, parent); }
      else if (nName == 'script') { parent = processScriptElement   (node, parent); }
      else if (nName == 'style')  { parent = processStyleElement    (node, parent); }
      else if (nName == 'link')   { parent = processLinkElement     (node, parent); }
      else if (nName == 'bml')    { parent = processBmlElement      (node, parent); }
      else if (nName == 'bevent') { parent = processBeventElement   (node, parent); }
      else if (nName == 'beitem') { parent = processBeitemElement   (node, parent); }
      else    { throw("not handled yet :["+node.nodeName+"]("+node.tagName+")"); }
    }
    else if (nType == NODETYPE.TEXT_NODE)             { parent = processTextNode(node, parent); }
    else if (nType == NODETYPE.CDATA_SECTION_NODE)    { 
      var parentName = String(parent.nodeName).toLowerCase();
      if      (parentName == 'style')  { parent = processStyleCDATASection (node, parent); }
      else if (parentName == 'script') { parent = processScriptCDATASection(node, parent); }
      else if (parentName == 'title')  { parent = processTextNode          (node, parent); }
      else if (parentName == 'span')   { parent = processTextNode          (node, parent); }
      else if (parentName == 'p')      { parent = processTextNode          (node, parent); }
      else if (parentName == 'a')      { parent = processTextNode          (node, parent); }
      else  { throw("not handled yet :["+node.nodeName+"]("+node.tagName+")"); }
    }
    else { throw("not handled yet :["+node.nodeName+"]("+node.tagName+")"); }
    
    var children = node.childNodes;
    for(var i = 0, l = children.length; i < l; i++) {
      rebuild(children[i], parent);
    }
  }
  
  //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  BML.Builder = {
    build : function(url) {
      var ajax = new BML.Ajax(url, {
        overrideMimeType : 'text/xml; charset=EUC-JP',
        asynchronous     : true,
        method           : 'GET',
        onSuccess : function(response) {
          BML.url = url;
          try {
            rebuild(response.responseXML, document, document);

            if (bodyElement) bodyElement['parent'].appendChild(bodyElement['body']);
            var body = getFirstElementByTagName('body', document);
            
            if (BML.Util.isSafari) {
              BML.Util.each.call(BML.config.suffixScriptIncPath, function(v) {
                body.appendChild(createExternalSrcScriptTag(v));
              });
            }
            
            if (eventHandlers['onload']) {
              var elm = setScriptAttributes(document.createElement('script'));
              elm.appendChild(document.createTextNode("eval(BML.Builder.eventHandlers['onload']);"));
              body.appendChild(elm);
            }
          } catch(e) {
            console.debug(e);
          }
        }
      });
    },
    eventHandlers : eventHandlers
  };
})();
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// ����browser���֥������ȴ�Ϣ
browser = (function() {
  ///////////////////////////////////////////////////////////////////////////////////////////
  // dummy function ->
  function getDRMID(str)  { return('1234567890abcdef'); }
  function getIRDID(type) { return('1234567890abcdef'); }
  function playRomSound(sID) { }
  function getDocManagementStat() { return(true); } // managed/unmanaged
  function readPersistentArray(fn, s) { return([20, false]); } //[ǯ��, ���¾���] 
  function checkIPTVServiceRegistrationInfo(id) { return([12345678, 0, 'license']); } // key,expire_date,license_uri
  // <- dummy function

  function lockScreen()   { }
  function unlockScreen() { }
  function getActiveDocument() {
    var uri = BML.Util.parseURI(location.href);
    return('/' + uri.path + uri.file);
  }
  function random(n) { return(1 + Math.floor(Math.random() * n)); }
  function clearTimer(id) { window.clearInterval(id); }
  function setInterval(func, ms, repeat) {
    ms = Math.max(100, Math.floor((ms + 99) / 100) * 100); // �����ͤ�100msñ��
    if (repeat === 0) repeat = -1;
    var timer = window.setInterval(function() {
      eval(func);
      if ((repeat > 0) && (--repeat === 0)) window.clearInterval(timer);
    }, ms);
    return(timer);
  }
  function transmitTextDataOverIP(url, text, charset) {
    charset = charset || 'EUC-JP';
    var ajax = new BML.Ajax(url,
                            ((text === null) || BML.Util.isUndefined(text)) ?
                            {
                              overrideMimeType : 'text/plane; charset=' + charset,
                              asynchronous     : false,
                              method           : 'GET'
                            } : 
                            {
                              overrideMimeType : 'text/plane; charset=' + charset,
                              asynchronous     : false,
                              method           : 'POST',
                              parameters       : { Denbun : text }
                            });
    var httpStatusCode = ajax.response.statusCode;
    if ((httpStatusCode < 200) || (httpStatusCode >= 300)) {
      if      (httpStatusCode ==  400) return([-1,  httpStatusCode, '']);
      else if (httpStatusCode ==  408) return([-3,  httpStatusCode, '']);
      else if (httpStatusCode !==   0) return([NaN, httpStatusCode, '']);
    }

    return([1, 200, ajax.response.responseText]);
  }
  function launchDocument(url, style) {
/*    url = (url || '').replace(/\.bml((\?\.+)?)/, '.html$1');
    if (url === '') return(NaN);
    location.href=url;
    return(1);*/
  }
  return({
    random                 : random,
    getDRMID               : getDRMID,
    getIRDID               : getIRDID,
    playRomSound           : playRomSound,
    lockScreen             : lockScreen,
    unlockScreen           : unlockScreen,
    clearTimer             : clearTimer,
    setInterval            : setInterval,
    launchDocument         : launchDocument,
    getActiveDocument      : getActiveDocument,
    getDocManagementStat   : getDocManagementStat,
    readPersistentArray    : readPersistentArray,
    transmitTextDataOverIP : transmitTextDataOverIP,
    checkIPTVServiceRegistrationInfo : checkIPTVServiceRegistrationInfo
  });
})();

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// ��ư����(IE̤�б��Τ���IE�ξ��ϲ���Ԥ�ʤ�)
/*@cc_on @if(1) (@_jscript)
  document.write('IE��̤�б��Ǥ�');
@else @*/
window.addEventListener('load', function() {
  var bmlUri = BML.Util.parseURI(location.href);
  bmlUri = decodeURIComponent(bmlUri.query);
  if (!bmlUri) return;

  BML.Builder.build(bmlUri);
}, false);
/*@end @*/
