<?php
if (!isset($_GET['img']))
{
	echo 'error input';
	exit();
}

//echo $_GET['img'];
//$img = imagecreatefromjpeg($_GET['img']);


//header('Content-type: image/jpeg');

//imagejpeg($img);

//imagedestroy($img);
phpinfo();
?>
