/**********************************************************************
 * Copyright (C) 2009 Nippon Telegraph and Telephone Corporation.
 * Copyright (C) 2010 Institute for Infocomm Research.
 * All rights reserved.
 **********************************************************************/

/************************************************************
 * Re-direct to actual data file.
 */
// There is no support for document.write() in LIME.
// document.write( '<script src="../data/data20091007b.js" />');
// document.getElementById( 'data_file').src = '../data/data_20091007b.js';

/************************************************************/
function dataFileLoc() {
	return( '../data/data_20091007b.js');
};

